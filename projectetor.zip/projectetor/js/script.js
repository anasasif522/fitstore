const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const header = document.querySelector('.site-header');
const onScroll = () => {
  if (!header) return;
  header.classList.toggle('scrolled', window.scrollY > 8);
};
window.addEventListener('scroll', onScroll);
onScroll();

const revealElements = document.querySelectorAll('.reveal');
if (prefersReducedMotion) {
  revealElements.forEach((el) => el.classList.add('is-visible'));
} else {
  const revealObserver = new IntersectionObserver(
    (entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      });
    },
    { threshold: 0.2 }
  );

  revealElements.forEach((el) => revealObserver.observe(el));
}

const counterTargets = document.querySelectorAll('[data-count]');
const animateCount = (el) => {
  if (el.dataset.counted === 'true') return;
  const raw = el.dataset.count || '0';
  const suffix = el.dataset.suffix || '';
  const decimals = raw.includes('.') ? raw.split('.')[1].length : 0;
  const target = parseFloat(raw);
  const duration = 1200;
  const startTime = performance.now();

  el.dataset.counted = 'true';

  const tick = (now) => {
    const progress = Math.min((now - startTime) / duration, 1);
    const value = target * progress;
    el.textContent = `${value.toFixed(decimals)}${suffix}`;
    if (progress < 1) requestAnimationFrame(tick);
  };

  requestAnimationFrame(tick);
};

if (prefersReducedMotion) {
  counterTargets.forEach((el) => {
    const suffix = el.dataset.suffix || '';
    el.textContent = `${el.dataset.count}${suffix}`;
  });
} else {
  const counterObserver = new IntersectionObserver(
    (entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        animateCount(entry.target);
        observer.unobserve(entry.target);
      });
    },
    { threshold: 0.6 }
  );

  counterTargets.forEach((el) => counterObserver.observe(el));
}

const accordionHeads = document.querySelectorAll('.accordion-head');
const closeBody = (body) => {
  body.classList.remove('active');
  body.style.maxHeight = '0px';
};

const openBody = (body) => {
  body.classList.add('active');
  body.style.maxHeight = `${body.scrollHeight}px`;
};

accordionHeads.forEach((head) => {
  head.addEventListener('click', () => {
    const body = head.nextElementSibling;
    if (!body) return;

    document.querySelectorAll('.accordion-body').forEach((el) => {
      if (el !== body) closeBody(el);
    });

    if (body.classList.contains('active')) {
      closeBody(body);
    } else {
      openBody(body);
    }
  });
});

if (accordionHeads.length) {
  const firstBody = accordionHeads[0].nextElementSibling;
  if (firstBody) openBody(firstBody);
}

window.addEventListener('resize', () => {
  document.querySelectorAll('.accordion-body.active').forEach((body) => {
    body.style.maxHeight = `${body.scrollHeight}px`;
  });
});
