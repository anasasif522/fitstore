<?php
// Start secure session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// FITSTORE DATABASE CONFIGURATION
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'fitstore_db';

// Try connection
$conn = @new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check if database exists
$db_ready = true;
if ($conn->connect_error) {
    $db_ready = false;
}

// Basic security helper for prepared statements
function executeQuery($conn, $sql, $params = [], $types = "") {
    $stmt = $conn->prepare($sql);
    if (!$stmt) return false;
    
    if ($params) {
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    return $stmt;
}

// AUTO-MIGRATION SYSTEM (Automated Management)
if ($db_ready) {
    $check_column = $conn->query("SHOW COLUMNS FROM `messages` LIKE 'reply_text'");
    if ($check_column && $check_column->num_rows === 0) {
        $conn->query("ALTER TABLE `messages` ADD `reply_text` TEXT DEFAULT NULL AFTER `message_directive`, ADD `replied_at` TIMESTAMP NULL DEFAULT NULL");
    }
}

?>


