/**
 * Component Loader with Local Fallback & Global Theme Management
 */

const FALLBACKS = {
    'header.html': `    <header class="site-header" id="site-header">
        <div class="container nav">
            <a href="index.html" class="logo">
                <span class="logo-fit">FIT</span><span class="logo-store">STORE</span>
            </a>
            <div class="nav-links">
                <a href="index.html">HOME</a>
                <a href="index.html#products">PRODUCTS</a>
                <a href="index.html#deals">DEALS</a>
                <a href="shop.html">SHOP</a>
                <a href="javascript:void(0)" onclick="openAIConsole()" style="color:var(--accent); font-weight:800; display:flex; align-items:center; gap:0.4rem;"><i class="fas fa-microchip"></i> AI HUB</a>
                <a href="blog.html">BLOG</a>
                <a href="track.html">TRACKING</a>
                <a href="contact.html">CONTACT</a>

            </div>
            <div style="display: flex; align-items: center; gap: 1.5rem;">
                <div id="theme-toggle" title="Switch Theme">
                    <i class="fas fa-moon"></i>
                </div>
                <div style="position: relative; cursor: pointer;" onclick="toggleCart(true)">
                    <span style="font-size: 1.5rem;">🛒</span>
                    <span class="cart-count" id="cart-counter">0</span>
                </div>
                <div class="hamburger" id="hamburger-btn">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
    </header>`,
    'foter.html': `    <footer class="site-footer" id="footer">
        <div class="footer-glow"></div>
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <a class="logo" href="index.html" style="font-size:1.6rem;">
                        <span class="logo-fit">FIT</span><span class="logo-store">STORE</span>
                    </a>
                    <p>Premium fitness supplements for elite performance. Science-backed formulas for real athletes.</p>
                </div>
                <div class="footer-col">
                    <h4>Quick Links</h4>
                    <a href="index.html">Home</a>
                    <a href="shop.html">Shop</a>
                </div>
            </div>
            <div class="footer-bottom">
                <p>© 2026 FitStore. All rights reserved.</p>
            </div>
        </div>
    </footer>`,
    'detail.html': `    <div id="detail-overlay">
        <span class="close-overlay" onclick="closeDetail()">&times;</span>
        <div class="detail-circular-container">
            <div class="circular-layout">
                <div class="orbit-data">
                    <div class="data-point dp-1"><small>CATEGORY</small><span id="det-cat"></span></div>
                    <div class="data-point dp-2"><small>SERVINGS</small><span id="det-serv"></span></div>
                    <div class="data-point dp-3"><small>KEY STAT</small><span id="det-stat"></span></div>
                    <div class="data-point dp-4"><small>PRICE</small><span id="det-price"></span></div>
                </div>
                <div class="center-image-wrap">
                    <img id="det-img" src="" alt="Product">
                </div>
            </div>
            <div class="detail-info-center">
                <h1 id="det-name" style="font-family:'Rajdhani';"></h1>
                <p id="det-desc"></p>
                <div style="display: flex; flex-direction: column; align-items: center;">
                    <div class="qty-control">
                        <button class="qty-btn" onclick="updateQty(-1)">-</button>
                        <span class="qty-val" id="det-qty">1</span>
                        <button class="qty-btn" onclick="updateQty(1)">+</button>
                    </div>
                    <button class="checkout-btn" id="add-btn" style="width: auto; padding: 1.2rem 4rem;">ADD TO STACK</button>
                </div>
            </div>
        </div>
    </div>`,
    'form.html': `    <div id="checkout-overlay">
        <div class="checkout-modal" style="max-width: 900px; display: flex; gap: 3rem; align-items: stretch;">
            <div style="flex: 1; display: flex; flex-direction: column; position: relative;">
                <div id="checkout-map"></div>
                <div class="street-preview" id="street-peek">
                    <div class="street-tag">DROID FOOTAGE</div>
                    <img src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=2070&auto=format&fit=crop" alt="Street View">
                    <div style="position:absolute; bottom:0.5rem; left:0.5rem; color:white; font-family:'Rajdhani'; font-size:0.7rem;">ZONE SECURED</div>
                </div>
                <div style="flex:1; background: rgba(0,0,0,0.3); border-radius: 16px; padding: 1.5rem; font-family:'Rajdhani';">
                    <p style="color:var(--accent); margin:0;">STATION: DEPOT-01</p>
                    <p style="color:var(--muted); margin:0;">GPS: ACTIVATED</p>
                </div>
            </div>
            <div style="flex: 1.2;">
                <span class="close-overlay" onclick="closeCheckout()">&times;</span>
                <div id="checkout-form-view">
                    <h2 style="font-family:'Rajdhani'; letter-spacing:2px;">SECURE DISPATCH</h2>
                    <form onsubmit="confirmOrder(event)">
                        <div class="checkout-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                            <div class="form-group" style="grid-column: span 2;"><label style="display:block; font-size:0.7rem; color:var(--accent); margin-bottom:5px;">FULL NAME</label><input type="text" required id="ship-name" style="width:100%; padding:0.8rem; background:rgba(255,255,255,0.05); border:1px solid var(--card-border); color:#fff; border-radius:8px;"></div>
                            <div class="form-group"><label style="display:block; font-size:0.7rem; color:var(--accent); margin-bottom:5px;">EMAIL</label><input type="email" required id="ship-email" style="width:100%; padding:0.8rem; background:rgba(255,255,255,0.05); border:1px solid var(--card-border); color:#fff; border-radius:8px;"></div>
                            <div class="form-group"><label style="display:block; font-size:0.7rem; color:var(--accent); margin-bottom:5px;">PHONE</label><input type="tel" required id="ship-phone" style="width:100%; padding:0.8rem; background:rgba(255,255,255,0.05); border:1px solid var(--card-border); color:#fff; border-radius:8px;"></div>
                            <div class="form-group" style="grid-column: span 2;"><label style="display:block; font-size:0.7rem; color:var(--accent); margin-bottom:5px;">DROP ZONE ADDRESS</label><textarea required rows="2" id="ship-addr" oninput="triggerMapLocalize()" style="width:100%; padding:0.8rem; background:rgba(255,255,255,0.05); border:1px solid var(--card-border); color:#fff; border-radius:8px;"></textarea></div>
                        </div>
                        <div class="order-summary-box" style="margin: 1.5rem 0; padding:1rem; background:rgba(255,107,0,0.1); border-radius:12px; text-align:center;"><h3 id="checkout-total-val" style="margin:0; font-family:'Rajdhani'; font-size:2rem; color:var(--accent);">$0.00</h3></div>
                        <button type="submit" class="checkout-btn" style="width: 100%; padding:1rem; background:var(--accent); color:#000; border:none; border-radius:12px; font-weight:900; cursor:pointer; font-family:'Rajdhani'; letter-spacing:1px;">AUTHORIZE DELIVERY</button>
                    </form>
                </div>
                <div id="success-modal" style="display:none; text-align:center; padding: 2rem 0;">
                    <h2 style="font-family:'Rajdhani'; color:var(--accent);">MISSION DEPLOYED</h2>
                    <p style="color:var(--muted); margin: 1rem 0;">Your elite supplements are now in transit.</p>
                    <button class="checkout-btn" onclick="window.location.reload()" style="padding:0.8rem 2rem; background:var(--accent); color:#000; border:none; border-radius:8px; font-weight:900; cursor:pointer;">RELOAD STORE</button>
                </div>
            </div>
        </div>
    </div>`
};

/**
 * THEME MANAGEMENT
 */
const THEMES = ['dark', 'navy-orange', 'green', 'light-green', 'light-blue', 'light-orange', 'light-purple', 'light-minimal'];
const htmlEl = document.documentElement;

/**
 * GLOBAL CURRENCY CONVERTER SYSTEM
 */
const CURRENCIES = {
    USD: { symbol: '$', rate: 1.0, label: 'USD ($)' },
    EUR: { symbol: '€', rate: 0.92, label: 'EUR (€)' },
    GBP: { symbol: '£', rate: 0.79, label: 'GBP (£)' },
    AED: { symbol: 'AED ', rate: 3.67, label: 'AED (AED)' },
    PKR: { symbol: 'Rs ', rate: 278.5, label: 'PKR (Rs)' },
    CAD: { symbol: 'CA$', rate: 1.36, label: 'CAD ($)' },
    AUD: { symbol: 'A$', rate: 1.52, label: 'AUD ($)' }
};

function getSelectedCurrency() {
    return localStorage.getItem('fitstore-currency') || 'USD';
}

function setSelectedCurrency(currCode) {
    if (!CURRENCIES[currCode]) currCode = 'USD';
    localStorage.setItem('fitstore-currency', currCode);
    const select = document.getElementById('checkout-currency-select');
    if (select) select.value = currCode;
    
    if (typeof updateCheckoutTotal === 'function') updateCheckoutTotal();
    if (typeof renderCartDrawer === 'function') renderCartDrawer();
    if (typeof updateCartUI === 'function') updateCartUI();
}

function formatPrice(amountUSD) {
    const currKey = getSelectedCurrency();
    const curr = CURRENCIES[currKey] || CURRENCIES.USD;
    const converted = ((amountUSD || 0) * curr.rate).toFixed(2);
    return `${curr.symbol}${converted}`;
}

function onCurrencySelectChange(currCode) {
    setSelectedCurrency(currCode);
}

function setTheme(theme) {
    if (!THEMES.includes(theme)) theme = 'dark';
    htmlEl.setAttribute('data-theme', theme);
    localStorage.setItem('fitstore-theme', theme);

    // Update icon in header
    const icon = document.querySelector('#theme-toggle i');
    if (icon) {
        icon.className = theme === 'dark' ? 'fas fa-moon' : 'fas fa-sun';
        // Add a nice rotation effect
        icon.style.transition = "transform 0.5s ease";
        icon.style.transform = "rotate(360deg)";
        setTimeout(() => icon.style.transform = "rotate(0deg)", 500);
    }
}


function initTheme() {
    const saved = localStorage.getItem('fitstore-theme') || 'dark';
    setTheme(saved);
}

function attachThemeToggle() {
    const btn = document.getElementById('theme-toggle');
    if (btn) {
        btn.onclick = () => {
            const current = htmlEl.getAttribute('data-theme');
            let nextIndex = (THEMES.indexOf(current) + 1) % THEMES.length;
            setTheme(THEMES[nextIndex]);
        };
    }
}

// Global init on script run
initTheme();

/**
 * COMPONENT LOADER
 */
async function loadComponent(id, file) {
    const placeholder = document.getElementById(id);
    if (!placeholder) return;

    try {
        const response = await fetch(file);
        if (!response.ok) throw new Error("CORS or File Not Found");
        placeholder.innerHTML = await response.text();
    } catch (err) {
        console.warn(`Loader Fallback: Using embedded string for ${file}`);
        placeholder.innerHTML = FALLBACKS[file] || `<p style="color:red">Failed to load ${file}</p>`;
    }

    // Auto-attach listeners after loading header
    if (file === 'header.html') {
        attachThemeToggle();
        attachHamburgerLogic(); // Global attachment
        
        // Re-apply current theme to update the icon state in the newly loaded header
        setTheme(htmlEl.getAttribute('data-theme'));
        
        // Update cart counter from storage automatically
        try {
            const cart = JSON.parse(localStorage.getItem('fitstore-cart') || '[]');
            const counter = document.getElementById('cart-counter');
            if (counter) counter.innerText = cart.length;
        } catch (e) {
            console.warn("Cart data corrupted, resetting.");
            localStorage.setItem('fitstore-cart', '[]');
        }
    }
}

/**
 * MOBILE NAV & HAMBURGER LOGIC
 */
function attachHamburgerLogic() {
    const hamburgerBtn = document.getElementById('hamburger-btn');
    const mobileNav = document.getElementById('mobile-nav');
    if (hamburgerBtn && mobileNav) {
        hamburgerBtn.onclick = () => {
            mobileNav.classList.toggle('open');
            const spans = hamburgerBtn.querySelectorAll('span');
            if (mobileNav.classList.contains('open')) {
                spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
                spans[1].style.opacity = '0';
                spans[2].style.transform = 'rotate(-45deg) translate(5px, -5px)';
            } else {
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            }
        };

        // Auto-close menu when any mobile link is clicked (crucial for anchors)
        mobileNav.querySelectorAll('a').forEach(link => {
            link.onclick = (e) => {
                const href = link.getAttribute('href');
                if (href.startsWith('#') || href.includes(window.location.pathname + '#') || href.includes('#')) {
                    mobileNav.classList.remove('open');
                    const spans = hamburgerBtn.querySelectorAll('span');
                    spans[0].style.transform = 'none';
                    spans[1].style.opacity = '1';
                    spans[2].style.transform = 'none';
                }
            };
        });
    }
}

/**
 * GLOBAL SLIDE-OUT MINI-CART DRAWER SYSTEM
 */
let appliedDiscountPct = 0;

function ensureCartDrawerHTML() {
    if (document.getElementById('side-cart-drawer')) return;

    const drawerHTML = `
        <div id="side-cart-overlay" onclick="toggleCart(false)" style="position:fixed; inset:0; background:rgba(0,0,0,0.7); backdrop-filter:blur(8px); z-index:99998; opacity:0; pointer-events:none; transition:0.3s;"></div>
        <div id="side-cart-drawer" style="position:fixed; top:0; right:-420px; width:100%; max-width:400px; height:100vh; background:rgba(8, 10, 24, 0.96); backdrop-filter:blur(30px); border-left:1px solid var(--card-border); z-index:99999; display:flex; flex-direction:column; padding:2rem 1.5rem; transition:right 0.4s cubic-bezier(0.165, 0.84, 0.44, 1); box-shadow:-10px 0 40px rgba(0,0,0,0.8);">
            <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--card-border); padding-bottom:1rem;">
                <h3 style="font-family:'Rajdhani'; font-size:1.5rem; margin:0; font-weight:900;">
                    TACTICAL <span style="color:var(--accent);">CART</span>
                </h3>
                <span onclick="toggleCart(false)" style="cursor:pointer; font-size:1.4rem; color:var(--muted); transition:0.2s;" onmouseover="this.style.color='var(--accent)'" onmouseout="this.style.color='var(--muted)'">&times;</span>
            </div>

            <!-- Free Shipping Progress -->
            <div style="margin:1rem 0; background:rgba(255,255,255,0.03); border:1px solid var(--card-border); padding:0.8rem 1rem; border-radius:14px;">
                <div id="shipping-progress-text" style="font-size:0.75rem; font-weight:800; font-family:'Rajdhani'; color:var(--accent); text-transform:uppercase; margin-bottom:0.4rem;">
                    EXPRESS DISPATCH METRICS
                </div>
                <div style="width:100%; height:6px; background:rgba(255,255,255,0.1); border-radius:10px; overflow:hidden;">
                    <div id="shipping-progress-bar" style="width:0%; height:100%; background:var(--accent); transition:width 0.5s ease;"></div>
                </div>
            </div>

            <!-- Cart Items Container -->
            <div id="drawer-items-list" style="flex:1; overflow-y:auto; margin:0.5rem 0; display:flex; flex-direction:column; gap:0.8rem;">
                <!-- Injected via renderCartDrawer() -->
            </div>

            <!-- Promo Code & Total -->
            <div style="border-top:1px solid var(--card-border); padding-top:1rem;">
                <div style="display:flex; gap:0.5rem; margin-bottom:1rem;">
                    <input type="text" id="promo-code-input" placeholder="PROMO CODE (e.g. FIT15)" style="flex:1; padding:0.6rem 1rem; background:rgba(255,255,255,0.05); border:1px solid var(--card-border); border-radius:10px; color:#fff; font-size:0.85rem; outline:none;">
                    <button onclick="applyPromoCode()" class="btn btn-blue" style="padding:0.6rem 1rem; font-size:0.8rem;">APPLY</button>
                </div>

                <div style="display:flex; justify-content:space-between; margin-bottom:0.4rem; font-size:0.9rem; color:var(--muted);">
                    <span>SUBTOTAL</span>
                    <span id="drawer-subtotal-val" style="color:#fff; font-weight:700;">$0.00</span>
                </div>
                <div id="drawer-discount-row" style="display:none; justify-content:space-between; margin-bottom:0.4rem; font-size:0.9rem; color:#22c55e;">
                    <span>PROMO DISCOUNT</span>
                    <span id="drawer-discount-val" style="font-weight:700;">-$0.00</span>
                </div>
                <div style="display:flex; justify-content:space-between; margin-bottom:1.2rem; font-size:1.2rem; font-weight:900; font-family:'Rajdhani';">
                    <span>ESTIMATED TOTAL</span>
                    <span id="drawer-total-val" style="color:var(--accent);">$0.00</span>
                </div>

                <button onclick="openCheckoutFromDrawer()" class="btn btn-green" style="width:100%; padding:0.9rem; font-size:1rem;">
                    PROCEED TO CHECKOUT <i class="fas fa-arrow-right"></i>
                </button>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', drawerHTML);
}

function toggleCart(show) {
    ensureCartDrawerHTML();
    const drawer = document.getElementById('side-cart-drawer');
    const overlay = document.getElementById('side-cart-overlay');
    if (!drawer || !overlay) return;

    if (show) {
        renderCartDrawer();
        overlay.style.opacity = '1';
        overlay.style.pointerEvents = 'auto';
        drawer.style.right = '0';
    } else {
        overlay.style.opacity = '0';
        overlay.style.pointerEvents = 'none';
        drawer.style.right = '-420px';
    }
}

function getCartData() {
    try {
        return JSON.parse(localStorage.getItem('fitstore-cart') || '[]');
    } catch(e) { return []; }
}

function setCartData(cart) {
    localStorage.setItem('fitstore-cart', JSON.stringify(cart));
    const counter = document.getElementById('cart-counter');
    if (counter) counter.innerText = cart.length;
}

function renderCartDrawer() {
    ensureCartDrawerHTML();
    const cart = getCartData();
    const list = document.getElementById('drawer-items-list');
    if (!list) return;

    if (cart.length === 0) {
        list.innerHTML = `
            <div style="text-align:center; padding:3rem 1rem; color:var(--muted);">
                <i class="fas fa-shopping-basket fa-2x" style="opacity:0.3; margin-bottom:1rem; color:var(--accent);"></i>
                <p style="font-weight:600; font-size:0.9rem;">Your tactical stack is empty.</p>
            </div>
        `;
    } else {
        list.innerHTML = cart.map((item, idx) => `
            <div style="display:flex; align-items:center; gap:0.8rem; background:rgba(255,255,255,0.03); border:1px solid var(--card-border); padding:0.8rem; border-radius:12px;">
                <div style="width:45px; height:45px; background:rgba(0,0,0,0.4); border-radius:8px; display:flex; align-items:center; justify-content:center; color:var(--accent); font-weight:900;">
                    ${item.name ? item.name.substring(0,2).toUpperCase() : 'FT'}
                </div>
                <div style="flex:1;">
                    <div style="font-size:0.85rem; font-weight:800; color:#fff; font-family:'Rajdhani'; line-height:1.2;">
                        ${item.name || 'Tactical Product'}
                    </div>
                    <div style="font-size:0.8rem; color:var(--accent); font-weight:700; margin-top:0.2rem;">
                        ${formatPrice(item.price || 0)}
                    </div>
                </div>
                <span onclick="removeFromCart(${idx})" style="cursor:pointer; color:var(--muted); font-size:0.9rem; padding:0.3rem;" onmouseover="this.style.color='#ef4444'" onmouseout="this.style.color='var(--muted)'">
                    <i class="fas fa-trash-alt"></i>
                </span>
            </div>
        `).join('');
    }

    const rawSubtotal = cart.reduce((sum, i) => sum + (i.price || 0), 0);
    const discountAmt = rawSubtotal * (appliedDiscountPct / 100);
    const finalTotal = rawSubtotal - discountAmt;

    const subEl = document.getElementById('drawer-subtotal-val');
    const totEl = document.getElementById('drawer-total-val');
    const discRow = document.getElementById('drawer-discount-row');
    const discVal = document.getElementById('drawer-discount-val');

    if (subEl) subEl.innerText = formatPrice(rawSubtotal);
    if (totEl) totEl.innerText = formatPrice(finalTotal);

    if (appliedDiscountPct > 0 && discRow && discVal) {
        discRow.style.display = 'flex';
        discVal.innerText = '-' + formatPrice(discountAmt);
    }

    // Update Free Shipping Progress ($100 target)
    const targetVal = 100;
    const pct = Math.min(100, (rawSubtotal / targetVal) * 100);
    const bar = document.getElementById('shipping-progress-bar');
    const txt = document.getElementById('shipping-progress-text');

    if (bar) bar.style.width = pct + '%';
    if (txt) {
        if (pct >= 100) {
            txt.innerText = '🎉 UNLOCKED FREE EXPRESS DISPATCH!';
            txt.style.color = '#22c55e';
        } else {
            const diff = targetVal - rawSubtotal;
            txt.innerText = `ADD $${diff.toFixed(2)} MORE FOR FREE EXPRESS DISPATCH`;
            txt.style.color = 'var(--accent)';
        }
    }
}

function removeFromCart(idx) {
    const cart = getCartData();
    cart.splice(idx, 1);
    setCartData(cart);
    renderCartDrawer();
}

function applyPromoCode() {
    const code = (document.getElementById('promo-code-input').value || '').trim().toUpperCase();
    if (code === 'FIT15') {
        appliedDiscountPct = 15;
        alert('PROMO CODE APPLIED: 15% OFF YOUR TACTICAL STACK!');
    } else if (code === 'PRO20') {
        appliedDiscountPct = 20;
        alert('PROMO CODE APPLIED: 20% ELITE ATHLETE DISCOUNT!');
    } else {
        alert('INVALID PROMO CODE. Try FIT15 or PRO20');
    }
    renderCartDrawer();
}

function openCheckoutFromDrawer() {
    toggleCart(false);
    if (typeof openCheckout === 'function') {
        openCheckout();
    } else {
        window.location.href = 'shop.html?checkout=1';
    }
}

/**
 * ===================================================
 * INTERACTIVE AI EXECUTION ENGINE (FITSTORE AI HUB)
 * ===================================================
 */

function ensureAIConsoleHTML() {
    if (document.getElementById('ai-console-overlay')) return;

    const styleTag = document.createElement('style');
    styleTag.innerHTML = `
        @keyframes aiGlowPulse {
            0% { box-shadow: 0 25px 80px rgba(0,0,0,0.9), 0 0 30px var(--accent-glow); }
            50% { box-shadow: 0 25px 90px rgba(0,0,0,0.95), 0 0 55px var(--accent-glow); }
            100% { box-shadow: 0 25px 80px rgba(0,0,0,0.9), 0 0 30px var(--accent-glow); }
        }
        @keyframes aiPulseDot {
            0% { transform: scale(0.95); opacity: 0.8; }
            50% { transform: scale(1.25); opacity: 1; }
            100% { transform: scale(0.95); opacity: 0.8; }
        }
        .ai-tab-btn:hover {
            border-color: var(--accent) !important;
            transform: translateY(-2px);
        }
        .ai-tab-btn.active {
            box-shadow: 0 4px 20px var(--accent-glow);
        }
        .ai-chat-bubble-user {
            background: linear-gradient(135deg, var(--accent) 0%, #ff8800 100%) !important;
            color: #030712 !important;
            font-weight: 800 !important;
            border-radius: 18px 18px 2px 18px !important;
            box-shadow: 0 8px 20px rgba(255,107,0,0.3) !important;
        }
        .ai-chat-bubble-agent {
            background: rgba(17, 24, 39, 0.75) !important;
            border: 1px solid var(--card-border) !important;
            border-radius: 18px 18px 18px 2px !important;
            backdrop-filter: blur(10px) !important;
            box-shadow: 0 8px 25px rgba(0,0,0,0.4) !important;
        }
    `;
    document.head.appendChild(styleTag);

    const consoleHTML = `
    <div id="ai-console-overlay" onclick="if(event.target===this) closeAIConsole()" style="position:fixed; inset:0; background:rgba(3,7,18,0.88); backdrop-filter:blur(25px); -webkit-backdrop-filter:blur(25px); z-index:100005; display:none; align-items:center; justify-content:center; padding:1.5rem; opacity:0; transition:opacity 0.4s ease;">
        <div class="ai-console-modal" style="width:100%; max-width:980px; height:86vh; max-height:800px; background:rgba(8, 12, 28, 0.96); border:1px solid var(--accent); border-radius:28px; animation:aiGlowPulse 4s infinite ease-in-out; display:flex; flex-direction:column; overflow:hidden; position:relative;">
            
            <!-- Modal Header -->
            <div style="padding:1.4rem 2rem; background:rgba(3,7,18,0.9); border-bottom:1px solid var(--card-border); display:flex; justify-content:space-between; align-items:center;">
                <div style="display:flex; align-items:center; gap:1rem;">
                    <div style="width:46px; height:46px; background:linear-gradient(135deg, var(--accent) 0%, #ff8800 100%); border-radius:14px; display:flex; align-items:center; justify-content:center; color:#030712; font-size:1.4rem; box-shadow:0 0 20px var(--accent-glow);">
                        <i class="fas fa-microchip"></i>
                    </div>
                    <div>
                        <h3 style="font-family:'Rajdhani'; font-size:1.6rem; font-weight:900; color:#fff; margin:0; letter-spacing:1px; line-height:1; display:flex; align-items:center; gap:0.5rem;">
                            FITSTORE <span style="color:var(--accent);">NEURAL AI AGENT</span>
                            <span style="font-size:0.7rem; background:rgba(34,197,94,0.15); border:1px solid #22c55e; color:#22c55e; padding:3px 10px; border-radius:20px; font-weight:800; display:inline-flex; align-items:center; gap:5px;">
                                <span style="width:6px; height:6px; background:#22c55e; border-radius:50%; animation:aiPulseDot 1.5s infinite;"></span> PRO V2.4 LIVE
                            </span>
                        </h3>
                        <small style="color:var(--muted); font-size:0.78rem; font-family:'Outfit', sans-serif;">Autonomous Performance, Physiology & Store Catalog Intelligence</small>
                    </div>
                </div>
                <button onclick="closeAIConsole()" style="background:rgba(255,255,255,0.05); border:1px solid var(--card-border); color:var(--muted); width:38px; height:38px; border-radius:50%; font-size:1.3rem; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:0.2s;" onmouseover="this.style.color='var(--accent)'; this.style.borderColor='var(--accent)';" onmouseout="this.style.color='var(--muted)'; this.style.borderColor='var(--card-border)';">&times;</button>
            </div>

            <!-- Gemini API Key Banner -->
            <div style="background:rgba(0,0,0,0.4); border-bottom:1px solid var(--card-border); padding:0.6rem 1.8rem; display:flex; align-items:center; justify-content:space-between; gap:1rem;">
                <div style="display:flex; align-items:center; gap:0.6rem; flex:1;">
                    <i class="fas fa-key" style="color:var(--accent); font-size:0.85rem;"></i>
                    <input type="password" id="gemini-api-key-input" placeholder="Google Gemini API Key Active (Paste key here to change)..." onchange="saveGeminiKey(this.value)" style="flex:1; background:rgba(255,255,255,0.04); border:1px solid var(--card-border); border-radius:8px; padding:0.45rem 0.9rem; color:#fff; font-size:0.8rem; font-family:'Rajdhani'; outline:none; transition:0.2s;" onfocus="this.style.borderColor='var(--accent)'" onblur="this.style.borderColor='var(--card-border)'">
                </div>
                <span id="gemini-status-badge" style="font-size:0.72rem; font-weight:800; font-family:'Rajdhani'; padding:4px 12px; border-radius:12px; background:rgba(34,197,94,0.15); border:1px solid #22c55e; color:#22c55e; white-space:nowrap;">
                    🟢 GEMINI 1.5 PRO CONNECTED
                </span>
            </div>

            <!-- Tab Navigation Bar -->
            <div style="display:flex; gap:0.6rem; padding:0.8rem 1.8rem; background:rgba(255,255,255,0.015); border-bottom:1px solid var(--card-border); overflow-x:auto;" id="ai-tabs-nav">
                <button class="ai-tab-btn active" onclick="switchAITab('coach')" data-tab="coach" style="padding:0.65rem 1.3rem; border-radius:12px; border:1px solid var(--card-border); background:rgba(255,255,255,0.05); color:#fff; font-family:'Rajdhani'; font-weight:800; font-size:0.92rem; cursor:pointer; display:flex; align-items:center; gap:0.5rem; white-space:nowrap; transition:0.2s;">
                    <i class="fas fa-robot" style="color:#f97316;"></i> RAG AI Coach
                </button>
                <button class="ai-tab-btn" onclick="switchAITab('physique')" data-tab="physique" style="padding:0.65rem 1.3rem; border-radius:12px; border:1px solid var(--card-border); background:rgba(255,255,255,0.05); color:#fff; font-family:'Rajdhani'; font-weight:800; font-size:0.92rem; cursor:pointer; display:flex; align-items:center; gap:0.5rem; white-space:nowrap; transition:0.2s;">
                    <i class="fas fa-child" style="color:#ec4899;"></i> Physique & Store Plan
                </button>
                <button class="ai-tab-btn" onclick="switchAITab('scanner')" data-tab="scanner" style="padding:0.65rem 1.3rem; border-radius:12px; border:1px solid var(--card-border); background:rgba(255,255,255,0.05); color:#fff; font-family:'Rajdhani'; font-weight:800; font-size:0.92rem; cursor:pointer; display:flex; align-items:center; gap:0.5rem; white-space:nowrap; transition:0.2s;">
                    <i class="fas fa-camera" style="color:#10b981;"></i> Meal Vision Scanner
                </button>
                <button class="ai-tab-btn" onclick="switchAITab('workout')" data-tab="workout" style="padding:0.65rem 1.3rem; border-radius:12px; border:1px solid var(--card-border); background:rgba(255,255,255,0.05); color:#fff; font-family:'Rajdhani'; font-weight:800; font-size:0.92rem; cursor:pointer; display:flex; align-items:center; gap:0.5rem; white-space:nowrap; transition:0.2s;">
                    <i class="fas fa-dumbbell" style="color:#38bdf8;"></i> Program Generator
                </button>
                <button class="ai-tab-btn" onclick="switchAITab('posenet')" data-tab="posenet" style="padding:0.65rem 1.3rem; border-radius:12px; border:1px solid var(--card-border); background:rgba(255,255,255,0.05); color:#fff; font-family:'Rajdhani'; font-weight:800; font-size:0.92rem; cursor:pointer; display:flex; align-items:center; gap:0.5rem; white-space:nowrap; transition:0.2s;">
                    <i class="fas fa-video" style="color:#a855f7;"></i> PoseNet Form AI
                </button>
                <button class="ai-tab-btn" onclick="switchAITab('pricing')" data-tab="pricing" style="padding:0.65rem 1.3rem; border-radius:12px; border:1px solid var(--card-border); background:rgba(255,255,255,0.05); color:#fff; font-family:'Rajdhani'; font-weight:800; font-size:0.92rem; cursor:pointer; display:flex; align-items:center; gap:0.5rem; white-space:nowrap; transition:0.2s;">
                    <i class="fas fa-brain" style="color:#fbbf24;"></i> Smart Pricing AI
                </button>
            </div>

            <!-- Modal Body Content -->
            <div style="flex:1; overflow-y:auto; padding:1.8rem; position:relative;" id="ai-modal-body">

                <!-- TAB 1: AI COACH CHATBOT -->
                <div class="ai-tab-content" id="ai-tab-coach" style="display:block; height:100%;">
                    <div style="display:flex; flex-direction:column; height:100%;">
                        <div style="margin-bottom:1rem;">
                            <span style="font-size:0.75rem; color:#f97316; font-weight:800; font-family:'Rajdhani'; text-transform:uppercase;">ASK THE RAG AI NUTRITIONAL COACH</span>
                            <h4 style="font-family:'Rajdhani'; font-size:1.3rem; color:#fff; margin:0.2rem 0;">Real-Time Supplement & Recovery Intelligence</h4>
                        </div>
                        <div style="display:flex; gap:0.4rem; flex-wrap:wrap; margin-bottom:1rem;">
                            <button onclick="sendAIChatPrompt('When is the best time to take ISO-WHEY ELITE?')" style="padding:0.4rem 0.8rem; border-radius:20px; background:rgba(249,115,22,0.1); border:1px solid rgba(249,115,22,0.3); color:#f97316; font-size:0.75rem; cursor:pointer; font-family:'Rajdhani'; font-weight:700;">💡 Timing ISO-WHEY?</button>
                            <button onclick="sendAIChatPrompt('Recommend a complete stack for hypertrophy and fast recovery')" style="padding:0.4rem 0.8rem; border-radius:20px; background:rgba(249,115,22,0.1); border:1px solid rgba(249,115,22,0.3); color:#f97316; font-size:0.75rem; cursor:pointer; font-family:'Rajdhani'; font-weight:700;">⚡ Hypertrophy Stack?</button>
                            <button onclick="sendAIChatPrompt('Can I stack NEON FORCE PRE with CREA-PURE MAX?')" style="padding:0.4rem 0.8rem; border-radius:20px; background:rgba(249,115,22,0.1); border:1px solid rgba(249,115,22,0.3); color:#f97316; font-size:0.75rem; cursor:pointer; font-family:'Rajdhani'; font-weight:700;">🧪 Stacking Pre + Creatine?</button>
                        </div>
                        <div id="ai-chat-history" style="flex:1; min-height:220px; max-height:340px; overflow-y:auto; background:rgba(0,0,0,0.3); border:1px solid var(--card-border); border-radius:16px; padding:1.2rem; display:flex; flex-direction:column; gap:1rem; margin-bottom:1rem;">
                            <div style="display:flex; gap:0.8rem; align-items:flex-start;">
                                <div style="width:36px; height:36px; background:#f97316; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#000; font-weight:900; font-size:0.9rem; flex-shrink:0;">AI</div>
                                <div style="background:rgba(255,255,255,0.06); border:1px solid var(--card-border); border-radius:14px; border-top-left-radius:2px; padding:0.9rem 1.2rem; max-width:80%; font-size:0.9rem; color:#e2e8f0; line-height:1.6;">
                                    Greetings Athlete! I am your <strong>FitStore Neural AI Coach</strong>. Ask me anything about supplement timing, stack synergy, macro calculations, or workout recovery protocols.
                                </div>
                            </div>
                        </div>
                        <form onsubmit="handleAIChatSubmit(event)" style="display:flex; gap:0.8rem;">
                            <input type="text" id="ai-chat-input" placeholder="Ask AI Coach (e.g. How to take Creatine for maximum ATP gain?)" style="flex:1; padding:0.9rem 1.2rem; background:rgba(255,255,255,0.05); border:1px solid var(--card-border); border-radius:14px; color:#fff; font-size:0.9rem; outline:none;" required>
                            <button type="submit" class="btn btn-primary" style="padding:0.9rem 1.8rem;">
                                SEND <i class="fas fa-paper-plane"></i>
                            </button>
                        </form>
                    </div>
                </div>

                <!-- TAB: PHYSIQUE & STORE PLANNER -->
                <div class="ai-tab-content" id="ai-tab-physique" style="display:none;">
                    <div style="margin-bottom:1rem;">
                        <span style="font-size:0.75rem; color:#ec4899; font-weight:800; font-family:'Rajdhani'; text-transform:uppercase;">GEMINI AI PHYSIQUE & CATALOG RECOMMENDER</span>
                        <h4 style="font-family:'Rajdhani'; font-size:1.3rem; color:#fff; margin:0.2rem 0;">Describe Your Physique & Receive Tailored Store Protocol</h4>
                    </div>

                    <div style="display:grid; grid-template-columns:1fr 1.2fr; gap:1.5rem; align-items:start;">
                        <div style="background:rgba(255,255,255,0.03); border:1px solid var(--card-border); padding:1.2rem; border-radius:16px;">
                            <div style="display:grid; grid-template-columns:1fr 1fr; gap:0.8rem; margin-bottom:1rem;">
                                <div>
                                    <label style="display:block; font-size:0.75rem; color:#ec4899; font-weight:800; font-family:'Rajdhani'; margin-bottom:0.3rem;">WEIGHT (KG)</label>
                                    <input type="number" id="phys-weight" value="75" style="width:100%; padding:0.65rem; background:rgba(0,0,0,0.4); border:1px solid var(--card-border); color:#fff; border-radius:8px; font-family:'Rajdhani'; font-weight:700;">
                                </div>
                                <div>
                                    <label style="display:block; font-size:0.75rem; color:#ec4899; font-weight:800; font-family:'Rajdhani'; margin-bottom:0.3rem;">HEIGHT (CM)</label>
                                    <input type="number" id="phys-height" value="178" style="width:100%; padding:0.65rem; background:rgba(0,0,0,0.4); border:1px solid var(--card-border); color:#fff; border-radius:8px; font-family:'Rajdhani'; font-weight:700;">
                                </div>
                            </div>
                            <div style="margin-bottom:1rem;">
                                <label style="display:block; font-size:0.75rem; color:#ec4899; font-weight:800; font-family:'Rajdhani'; margin-bottom:0.3rem;">ATHLETIC GOAL</label>
                                <select id="phys-goal" style="width:100%; padding:0.65rem; background:rgba(0,0,0,0.4); border:1px solid var(--card-border); color:#fff; border-radius:8px; font-family:'Rajdhani'; font-weight:700;">
                                    <option value="Hypertrophy Mass Bulk">Hypertrophy & Mass Growth</option>
                                    <option value="Fat Shred & Recomp">Fat Shred & Muscle Recomp</option>
                                    <option value="Hardgainer Caloric Mass">Hardgainer Caloric Mass</option>
                                    <option value="Explosive Power ATP Focus">Explosive Power & ATP</option>
                                </select>
                            </div>
                            <div style="margin-bottom:1rem;">
                                <label style="display:block; font-size:0.75rem; color:#ec4899; font-weight:800; font-family:'Rajdhani'; margin-bottom:0.3rem;">DESCRIBE YOUR PHYSIQUE & FLAWS</label>
                                <textarea id="phys-desc" rows="3" placeholder="e.g. Skinny fat, 18% body fat, lagging upper chest, fatigue mid-workout, slow leg recovery." style="width:100%; padding:0.7rem; background:rgba(0,0,0,0.4); border:1px solid var(--card-border); color:#fff; border-radius:8px; font-size:0.85rem; outline:none;"></textarea>
                            </div>
                            <button onclick="analyzePhysiqueWithAI()" class="btn" style="width:100%; padding:0.85rem; background:linear-gradient(135deg, #ec4899 0%, #be185d 100%); color:#fff; font-weight:900;">
                                ⚡ ANALYZE PHYSIQUE WITH GEMINI AI
                            </button>
                        </div>

                        <div style="background:rgba(0,0,0,0.3); border:1px solid var(--card-border); border-radius:16px; padding:1.2rem; min-height:300px;" id="phys-output-card">
                            <div style="font-weight:900; font-family:'Rajdhani'; color:#ec4899; font-size:1.1rem; margin-bottom:0.8rem; display:flex; justify-content:space-between; align-items:center;">
                                <span>💪 GEMINI PHYSIQUE & STORE PLAN</span>
                                <span style="font-size:0.75rem; color:var(--accent); font-family:'Rajdhani';" id="phys-mode-indicator">READY</span>
                            </div>
                            <div id="phys-output-content" style="font-size:0.85rem; color:#e2e8f0; line-height:1.6;">
                                Describe your body metrics and physique flaws on the left, then click <strong>ANALYZE PHYSIQUE WITH GEMINI AI</strong> to generate your custom transformation protocol matched with available FitStore supplements!
                            </div>
                        </div>
                    </div>
                </div>

                <!-- TAB 2: MEAL PHOTO SCANNER -->
                <div class="ai-tab-content" id="ai-tab-scanner" style="display:none;">
                    <div style="margin-bottom:1rem;">
                        <span style="font-size:0.75rem; color:#10b981; font-weight:800; font-family:'Rajdhani'; text-transform:uppercase;">VISION API MACRO SCANNER</span>
                        <h4 style="font-family:'Rajdhani'; font-size:1.3rem; color:#fff; margin:0.2rem 0;">Scan Meal Photo & Calculate Required Supplement Scoops</h4>
                    </div>

                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:1.5rem; align-items:start;">
                        <div>
                            <label style="display:block; font-size:0.8rem; color:var(--muted); margin-bottom:0.5rem; font-weight:700;">SELECT SAMPLE MEAL OR UPLOAD PHOTO:</label>
                            <div style="display:grid; grid-template-columns:1fr 1fr; gap:0.8rem; margin-bottom:1rem;">
                                <div onclick="selectSampleMeal('chicken')" class="meal-sample-card" id="meal-chicken" style="background:rgba(255,255,255,0.04); border:2px solid var(--accent); padding:0.8rem; border-radius:12px; cursor:pointer; text-align:center; transition:0.2s;">
                                    <img src="https://images.unsplash.com/photo-1532550907401-a500c9a57435?q=80&w=400&auto=format&fit=crop" style="width:100%; height:80px; object-fit:cover; border-radius:8px; margin-bottom:0.4rem;">
                                    <div style="font-size:0.8rem; font-weight:800; font-family:'Rajdhani'; color:#fff;">Grilled Chicken & Rice</div>
                                </div>
                                <div onclick="selectSampleMeal('oats')" class="meal-sample-card" id="meal-oats" style="background:rgba(255,255,255,0.04); border:1px solid var(--card-border); padding:0.8rem; border-radius:12px; cursor:pointer; text-align:center; transition:0.2s;">
                                    <img src="https://images.unsplash.com/photo-1517673400267-0251440c45dc?q=80&w=400&auto=format&fit=crop" style="width:100%; height:80px; object-fit:cover; border-radius:8px; margin-bottom:0.4rem;">
                                    <div style="font-size:0.8rem; font-weight:800; font-family:'Rajdhani'; color:#fff;">Protein Oats & Berries</div>
                                </div>
                            </div>
                            <button onclick="runMealScanner()" class="btn btn-green" style="width:100%; padding:0.9rem;">
                                <i class="fas fa-camera"></i> RUN AI VISION MACRO SCAN
                            </button>
                        </div>

                        <div id="meal-scan-results" style="background:rgba(0,0,0,0.3); border:1px solid var(--card-border); border-radius:16px; padding:1.2rem;">
                            <div style="font-weight:900; font-family:'Rajdhani'; color:#10b981; font-size:1.1rem; margin-bottom:0.8rem;">
                                📊 AI SCAN ANALYSIS OUTPUT
                            </div>
                            <div id="meal-scan-loading" style="display:none; text-align:center; padding:2rem 0;">
                                <i class="fas fa-circle-notch fa-spin fa-2x" style="color:#10b981; margin-bottom:0.8rem;"></i>
                                <div style="font-size:0.85rem; color:var(--muted);">Analyzing pixels with Computer Vision Model...</div>
                            </div>
                            <div id="meal-scan-details">
                                <div style="display:grid; grid-template-columns:1fr 1fr; gap:0.8rem; margin-bottom:1rem;">
                                    <div style="background:rgba(255,255,255,0.05); padding:0.8rem; border-radius:10px; text-align:center;">
                                        <small style="color:var(--muted); font-size:0.7rem;">DETECTED PROTEIN</small>
                                        <div style="font-size:1.4rem; font-weight:900; font-family:'Rajdhani'; color:#10b981;" id="res-prot">38g</div>
                                    </div>
                                    <div style="background:rgba(255,255,255,0.05); padding:0.8rem; border-radius:10px; text-align:center;">
                                        <small style="color:var(--muted); font-size:0.7rem;">CALORIES</small>
                                        <div style="font-size:1.4rem; font-weight:900; font-family:'Rajdhani'; color:#fff;" id="res-cal">520 kcal</div>
                                    </div>
                                </div>
                                <div style="background:rgba(16,185,129,0.1); border:1px solid rgba(16,185,129,0.3); padding:1rem; border-radius:12px; margin-bottom:1rem;">
                                    <div style="font-size:0.85rem; font-weight:800; color:#10b981; font-family:'Rajdhani';">
                                        💡 AI RECOMMENDATION:
                                    </div>
                                    <div style="font-size:0.85rem; color:#e2e8f0; margin-top:0.3rem;" id="res-rec">
                                        Meal protein is strong! Add <strong>1 Scoop of ISO-WHEY ELITE</strong> post-meal to reach peak 65g target.
                                    </div>
                                </div>
                                <button onclick="addToCart(1, 1, 'ISO-WHEY ELITE (1 Scoop Rec)', 64.99)" class="btn btn-green" style="width:100%; font-size:0.85rem; padding:0.7rem;">
                                    🛒 ADD RECOMMENDED ISO-WHEY TO STACK
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- TAB 3: WORKOUT GENERATOR -->
                <div class="ai-tab-content" id="ai-tab-workout" style="display:none;">
                    <div style="margin-bottom:1rem;">
                        <span style="font-size:0.75rem; color:#38bdf8; font-weight:800; font-family:'Rajdhani'; text-transform:uppercase;">AI HYPERTROPHY ENGINE</span>
                        <h4 style="font-family:'Rajdhani'; font-size:1.3rem; color:#fff; margin:0.2rem 0;">Generate Custom Training & Supplement Integration Split</h4>
                    </div>

                    <div style="display:grid; grid-template-columns:1fr 2fr; gap:1.5rem; align-items:start;">
                        <div style="background:rgba(255,255,255,0.03); border:1px solid var(--card-border); padding:1.2rem; border-radius:16px;">
                            <div style="margin-bottom:1rem;">
                                <label style="display:block; font-size:0.75rem; color:#38bdf8; font-weight:800; font-family:'Rajdhani'; margin-bottom:0.4rem;">PRIMARY TARGET</label>
                                <select id="wo-goal" style="width:100%; padding:0.7rem; background:rgba(0,0,0,0.4); border:1px solid var(--card-border); color:#fff; border-radius:8px; font-family:'Rajdhani'; font-weight:700;">
                                    <option value="Hypertrophy (Mass Bulk)">Hypertrophy (Mass Bulk)</option>
                                    <option value="Shred & Power Cut">Shred & Power Cut</option>
                                    <option value="Peak ATP Explosive Power">Peak ATP Explosive Power</option>
                                </select>
                            </div>
                            <div style="margin-bottom:1rem;">
                                <label style="display:block; font-size:0.75rem; color:#38bdf8; font-weight:800; font-family:'Rajdhani'; margin-bottom:0.4rem;">FREQUENCY</label>
                                <select id="wo-freq" style="width:100%; padding:0.7rem; background:rgba(0,0,0,0.4); border:1px solid var(--card-border); color:#fff; border-radius:8px; font-family:'Rajdhani'; font-weight:700;">
                                    <option value="4 Days / Week (Upper-Lower Split)">4 Days / Week (Upper-Lower)</option>
                                    <option value="5 Days / Week (Push-Pull-Legs)">5 Days / Week (PPL Split)</option>
                                </select>
                            </div>
                            <button onclick="generateAIWorkout()" class="btn btn-blue" style="width:100%; padding:0.8rem; font-size:0.9rem;">
                                ⚡ GENERATE AI PROGRAM
                            </button>
                        </div>

                        <div id="wo-output" style="background:rgba(0,0,0,0.3); border:1px solid var(--card-border); border-radius:16px; padding:1.2rem; min-height:260px;">
                            <div style="font-weight:900; font-family:'Rajdhani'; color:#38bdf8; font-size:1.1rem; margin-bottom:0.8rem;">
                                🏋️ CUSTOM NEURAL TRAINING PLAN
                            </div>
                            <div id="wo-list" style="display:flex; flex-direction:column; gap:0.7rem;">
                                <div style="background:rgba(255,255,255,0.04); border-left:3px solid #38bdf8; padding:0.8rem; border-radius:8px;">
                                    <div style="font-weight:800; color:#fff; font-family:'Rajdhani'; font-size:0.95rem;">DAY 1: HEAVY UPPER PUSH & ATP ACTIVATION</div>
                                    <small style="color:var(--muted);">Bench Press (4x8) · Incline Dumbbell Press (3x10) · Overhead Press (3x8) | <strong>Take 1 scoop NEON FORCE PRE 20m prior.</strong></small>
                                </div>
                                <div style="background:rgba(255,255,255,0.04); border-left:3px solid #10b981; padding:0.8rem; border-radius:8px;">
                                    <div style="font-weight:800; color:#fff; font-family:'Rajdhani'; font-size:0.95rem;">DAY 2: QUAD & HYPERTROPHY PULL</div>
                                    <small style="color:var(--muted);">Barbell Squat (4x6) · Romanian Deadlift (3x10) · Lat Pulldown (4x10) | <strong>Intra-workout: RECOVER BCAA+ in 500ml cold water.</strong></small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- TAB 4: POSENET FORM ANALYZER -->
                <div class="ai-tab-content" id="ai-tab-posenet" style="display:none;">
                    <div style="margin-bottom:1rem;">
                        <span style="font-size:0.75rem; color:#a855f7; font-weight:800; font-family:'Rajdhani'; text-transform:uppercase;">POSENET COMPUTER VISION</span>
                        <h4 style="font-family:'Rajdhani'; font-size:1.3rem; color:#fff; margin:0.2rem 0;">Real-Time Movement Kinematics & Depth Analysis</h4>
                    </div>

                    <div style="display:grid; grid-template-columns:1.5fr 1fr; gap:1.5rem; align-items:center;">
                        <div style="position:relative; background:#000; border-radius:16px; overflow:hidden; border:1px solid rgba(168,85,247,0.4); height:280px; display:flex; align-items:center; justify-content:center;">
                            <img src="https://images.unsplash.com/photo-1517838277536-f5f99be501cd?q=80&w=800&auto=format&fit=crop" style="width:100%; height:100%; object-fit:cover; opacity:0.7;">
                            <svg style="position:absolute; inset:0; width:100%; height:100%; pointer-events:none;">
                                <circle cx="50%" cy="25%" r="8" fill="#a855f7" stroke="#fff" stroke-width="2"/>
                                <line x1="50%" y1="25%" x2="50%" y2="50%" stroke="#a855f7" stroke-width="4"/>
                                <line x1="50%" y1="50%" x2="35%" y2="75%" stroke="#10b981" stroke-width="4"/>
                                <line x1="50%" y1="50%" x2="65%" y2="75%" stroke="#10b981" stroke-width="4"/>
                                <circle cx="35%" cy="75%" r="6" fill="#10b981"/>
                                <circle cx="65%" cy="75%" r="6" fill="#10b981"/>
                            </svg>
                            <div style="position:absolute; top:1rem; left:1rem; background:rgba(0,0,0,0.8); border:1px solid #a855f7; color:#a855f7; padding:0.3rem 0.8rem; border-radius:20px; font-size:0.75rem; font-family:'Rajdhani'; font-weight:800;">
                                🔴 LIVE POSENET FEED (SIMULATED)
                            </div>
                        </div>

                        <div style="background:rgba(0,0,0,0.3); border:1px solid var(--card-border); border-radius:16px; padding:1.2rem;">
                            <div style="font-weight:900; font-family:'Rajdhani'; color:#a855f7; font-size:1.1rem; margin-bottom:0.8rem;">
                                📐 KINEMATIC METRICS
                            </div>
                            <div style="display:flex; flex-direction:column; gap:0.6rem; font-size:0.85rem;">
                                <div style="display:flex; justify-content:space-between; border-bottom:1px solid rgba(255,255,255,0.06); padding-bottom:0.4rem;">
                                    <span style="color:var(--muted);">Knee Flexion Angle:</span>
                                    <strong style="color:#10b981; font-family:'Rajdhani';">94° (Parallel ✅)</strong>
                                </div>
                                <div style="display:flex; justify-content:space-between; border-bottom:1px solid rgba(255,255,255,0.06); padding-bottom:0.4rem;">
                                    <span style="color:var(--muted);">Lumbar Spine Neutral:</span>
                                    <strong style="color:#10b981; font-family:'Rajdhani';">98% Alignment</strong>
                                </div>
                                <div style="display:flex; justify-content:space-between; border-bottom:1px solid rgba(255,255,255,0.06); padding-bottom:0.4rem;">
                                    <span style="color:var(--muted);">Bar Path Balance:</span>
                                    <strong style="color:#a855f7; font-family:'Rajdhani';">96 / 100 Score</strong>
                                </div>
                            </div>
                            <div style="margin-top:1rem; background:rgba(168,85,247,0.1); border:1px solid rgba(168,85,247,0.3); padding:0.8rem; border-radius:10px; font-size:0.75rem; color:#e2e8f0; line-height:1.5;">
                                💬 <strong>AI COACH FEEDBACK:</strong> Exceptional depth. Keep your heels glued to the floor and drive aggressively out of the hole.
                            </div>
                        </div>
                    </div>
                </div>

                <!-- TAB 5: SMART PRICING AI -->
                <div class="ai-tab-content" id="ai-tab-pricing" style="display:none;">
                    <div style="margin-bottom:1rem;">
                        <span style="font-size:0.75rem; color:#fbbf24; font-weight:800; font-family:'Rajdhani'; text-transform:uppercase;">PERSONALIZATION ENGINE</span>
                        <h4 style="font-family:'Rajdhani'; font-size:1.3rem; color:#fff; margin:0.2rem 0;">AI Dynamic Bundle Discount & Telemetry Analyzer</h4>
                    </div>

                    <div style="background:rgba(255,255,255,0.03); border:1px solid var(--card-border); padding:1.5rem; border-radius:16px; text-align:center;">
                        <i class="fas fa-brain fa-3x" style="color:#fbbf24; margin-bottom:1rem;"></i>
                        <h4 style="font-family:'Rajdhani'; font-size:1.4rem; color:#fff; font-weight:900;">AI SMART STACK OPTIMIZER</h4>
                        <p style="color:var(--muted); font-size:0.9rem; max-width:500px; margin:0.5rem auto 1.2rem;">
                            Based on your active session telemetry, the AI algorithm has generated a <strong>Special 15% Dynamic Stack Bundle Discount</strong> for your next purchase!
                        </p>
                        <button onclick="applyAIBundleDiscount()" class="btn" style="background:linear-gradient(135deg, #fbbf24 0%, #d97706 100%); color:#000; padding:0.9rem 2.2rem; font-weight:900;">
                            ⚡ APPLY AI 15% DISCOUNT (CODE: FIT15)
                        </button>
                    </div>
                </div>

            </div>
        </div>
    </div>
    `;

    document.body.insertAdjacentHTML('beforeend', consoleHTML);
}

function openAIConsole(defaultTab = 'coach') {
    ensureAIConsoleHTML();
    updateGeminiBadge();
    const overlay = document.getElementById('ai-console-overlay');
    if (!overlay) return;
    overlay.style.display = 'flex';
    setTimeout(() => {
        overlay.style.opacity = '1';
    }, 10);
    switchAITab(defaultTab);
}

function closeAIConsole() {
    const overlay = document.getElementById('ai-console-overlay');
    if (!overlay) return;
    overlay.style.opacity = '0';
    setTimeout(() => {
        overlay.style.display = 'none';
    }, 400);
}

function switchAITab(tabId) {
    document.querySelectorAll('.ai-tab-btn').forEach(btn => {
        if (btn.dataset.tab === tabId) {
            btn.classList.add('active');
            btn.style.background = 'var(--accent)';
            btn.style.color = '#000';
        } else {
            btn.classList.remove('active');
            btn.style.background = 'rgba(255,255,255,0.05)';
            btn.style.color = '#fff';
        }
    });

    document.querySelectorAll('.ai-tab-content').forEach(content => {
        content.style.display = content.id === `ai-tab-${tabId}` ? 'block' : 'none';
    });
}

function sendAIChatPrompt(promptText) {
    const input = document.getElementById('ai-chat-input');
    if (input) {
        input.value = promptText;
        handleAIChatSubmit({ preventDefault: () => {} });
    }
}

const DEFAULT_GEMINI_KEY = 'AQ.Ab8RN6JtSZf6TppzYRuduN8JIoes2uUV_nukC0_xLNMfHw9jkQ';

function getGeminiAPIKey() {
    return localStorage.getItem('fitstore-gemini-key') || DEFAULT_GEMINI_KEY;
}

function saveGeminiKey(val) {
    const cleanKey = (val || '').trim();
    if (cleanKey) {
        localStorage.setItem('fitstore-gemini-key', cleanKey);
    } else {
        localStorage.removeItem('fitstore-gemini-key');
    }
    updateGeminiBadge();
}

function updateGeminiBadge() {
    const key = getGeminiAPIKey();
    const badge = document.getElementById('gemini-status-badge');
    const input = document.getElementById('gemini-api-key-input');
    if (input && document.activeElement !== input) input.value = key;
    if (badge) {
        if (key) {
            badge.innerHTML = '🟢 GEMINI 1.5 LIVE CONNECTED';
            badge.style.borderColor = '#22c55e';
            badge.style.color = '#22c55e';
            badge.style.background = 'rgba(34,197,94,0.15)';
        } else {
            badge.innerHTML = '⚡ HYBRID MODE (FALLBACK READY)';
            badge.style.borderColor = 'var(--accent)';
            badge.style.color = 'var(--accent)';
            badge.style.background = 'rgba(255,107,0,0.15)';
        }
    }
}

async function callGeminiAPI(userPrompt) {
    const apiKey = getGeminiAPIKey();
    if (!apiKey) return null;

    const systemPrompt = `You are FitStore's Elite AI Sports Performance & Physique Advisor powered by Google Gemini.
FitStore available catalog products:
1. ISO-WHEY ELITE ($64.99) - Pure Isolate Protein (26g Protein) for fast post-workout recovery.
2. NEON FORCE PRE ($45.00) - Explosive energy & focus (300mg Caffeine).
3. CREA-PURE MAX ($29.99) - ATP & muscle cell volume (5g Micronized Creatine).
4. RECOVER BCAA+ ($38.00) - Intra-workout hydration & recovery (7g BCAA).
5. MASS GAINER PRO ($79.99) - High calorie mass builder (1200 Cal).
6. Z-MAX NIGHT ($32.00) - Sleep quality & anabolic recovery (Zinc + Mg).
7. VITA-STACK ($24.99) - Complete 24 Vit/Min multivitamin.
8. OMEGA ELITE ($35.00) - Joint & heart health (1000mg EPA).

Analyze the user's physique description, body goals, or questions. 
Give actionable, expert sports nutrition advice. Match their physique goals with exact FitStore products.
Keep your response tactical, clear, concise, and structured with HTML formatting (e.g., <strong>bold</strong>, <ul><li>lists</li></ul>).`;

    try {
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [
                    {
                        role: 'user',
                        parts: [{ text: systemPrompt + "\n\nUser Question/Physique Data: " + userPrompt }]
                    }
                ]
            })
        });

        if (response.ok) {
            const data = await response.json();
            if (data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts[0]) {
                return data.candidates[0].content.parts[0].text;
            }
        }
    } catch (e) {
        console.warn("Gemini API call failed, switching to local neural fallback:", e);
    }
    return null;
}

async function handleAIChatSubmit(e) {
    if (e && e.preventDefault) e.preventDefault();
    const input = document.getElementById('ai-chat-input');
    const history = document.getElementById('ai-chat-history');
    if (!input || !history) return;

    const userText = input.value.trim();
    if (!userText) return;

    history.innerHTML += `
        <div style="display:flex; gap:0.8rem; align-items:flex-start; justify-content:flex-end;">
            <div style="background:var(--accent); color:#000; font-weight:800; border-radius:14px; border-top-right-radius:2px; padding:0.8rem 1.2rem; max-width:80%; font-size:0.9rem;">
                ${userText}
            </div>
        </div>
    `;
    input.value = '';
    history.scrollTop = history.scrollHeight;

    // Show AI typing placeholder
    const typingId = 'typing-' + Date.now();
    history.innerHTML += `
        <div id="${typingId}" style="display:flex; gap:0.8rem; align-items:flex-start;">
            <div style="width:36px; height:36px; background:#f97316; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#000; font-weight:900; font-size:0.9rem; flex-shrink:0;">AI</div>
            <div style="background:rgba(255,255,255,0.06); border:1px solid var(--card-border); border-radius:14px; border-top-left-radius:2px; padding:0.9rem 1.2rem; max-width:80%; font-size:0.9rem; color:#e2e8f0;">
                <i class="fas fa-circle-notch fa-spin" style="color:#f97316;"></i> Gemini AI thinking...
            </div>
        </div>
    `;
    history.scrollTop = history.scrollHeight;

    let reply = await callGeminiAPI(userText);
    
    if (!reply) {
        // Local Neural Fallback Response Generator
        const text = userText.toLowerCase();
        if (text.includes('physique') || text.includes('body') || text.includes('chest') || text.includes('thin') || text.includes('skinny')) {
            reply = "Based on your physique profile, your priority is <strong>hypertrophy & ATP cell volume</strong>. Stack <strong>ISO-WHEY ELITE</strong> ($64.99) post-workout with 5g <strong>CREA-PURE MAX</strong> ($29.99) daily to accelerate muscle fiber repair.";
        } else if (text.includes('pre') || text.includes('energy') || text.includes('fatigue')) {
            reply = "To eliminate workout fatigue, take 1 scoop of <strong>NEON FORCE PRE</strong> ($45.00) 20 minutes before training for explosive energy, plus <strong>RECOVER BCAA+</strong> ($38.00) intra-workout for hydration.";
        } else {
            reply = "According to sports nutrition research, combining <strong>ISO-WHEY ELITE</strong> post-workout with 5g <strong>CREA-PURE MAX</strong> daily provides optimal protein synthesis and intracellular hydration. For sleep recovery, take <strong>Z-MAX NIGHT</strong> before bed.";
        }
    }

    const typingEl = document.getElementById(typingId);
    if (typingEl) typingEl.remove();

    history.innerHTML += `
        <div style="display:flex; gap:0.8rem; align-items:flex-start;">
            <div style="width:36px; height:36px; background:#f97316; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#000; font-weight:900; font-size:0.9rem; flex-shrink:0;">AI</div>
            <div style="background:rgba(255,255,255,0.06); border:1px solid var(--card-border); border-radius:14px; border-top-left-radius:2px; padding:0.9rem 1.2rem; max-width:80%; font-size:0.9rem; color:#e2e8f0; line-height:1.6;">
                ${reply}
            </div>
        </div>
    `;
    history.scrollTop = history.scrollHeight;
}

async function analyzePhysiqueWithAI() {
    const weight = document.getElementById('phys-weight').value || 75;
    const height = document.getElementById('phys-height').value || 178;
    const goal = document.getElementById('phys-goal').value || 'Hypertrophy Mass Bulk';
    const desc = document.getElementById('phys-desc').value.trim() || 'Skinny fat, lagging chest and arms, fatigue mid-workout.';

    const outputCard = document.getElementById('phys-output-content');
    const modeIndicator = document.getElementById('phys-mode-indicator');
    if (!outputCard) return;

    outputCard.innerHTML = `
        <div style="text-align:center; padding:2rem 0;">
            <i class="fas fa-brain fa-spin fa-2x" style="color:#ec4899; margin-bottom:0.8rem;"></i>
            <div style="font-size:0.9rem; font-weight:700; color:#fff;">Analyzing Physique Parameters with Gemini AI...</div>
            <small style="color:var(--muted);">Matching body composition with FitStore catalog supplements</small>
        </div>
    `;

    const userPrompt = `Athlete Body Info: Weight ${weight}kg, Height ${height}cm. Goal: ${goal}. Physique Description & Weak Points: "${desc}". Match this athlete's physique with the best FitStore products (ISO-WHEY ELITE, NEON FORCE PRE, CREA-PURE MAX, RECOVER BCAA+, MASS GAINER PRO, Z-MAX NIGHT, VITA-STACK, OMEGA ELITE). Give a complete workout & supplement plan.`;

    let aiResult = await callGeminiAPI(userPrompt);

    if (aiResult) {
        if (modeIndicator) modeIndicator.innerText = '🟢 GEMINI 1.5 LIVE';
        outputCard.innerHTML = `
            <div style="background:rgba(236,72,153,0.1); border:1px solid rgba(236,72,153,0.3); padding:1rem; border-radius:12px; margin-bottom:1rem;">
                <div style="font-weight:900; font-family:'Rajdhani'; color:#ec4899; font-size:1rem; margin-bottom:0.5rem;">
                    🤖 GEMINI AI PHYSIQUE ANALYSIS & PROTOCOL
                </div>
                <div style="font-size:0.85rem; line-height:1.65; color:#f1f5f9;">
                    ${aiResult}
                </div>
            </div>
            <button onclick="addToCart(1,1); addToCart(3,1); addToCart(2,1);" class="btn" style="width:100%; background:linear-gradient(135deg, #10b981 0%, #059669 100%); color:#fff; font-weight:900; padding:0.8rem;">
                🛒 ADD RECOMMENDED PHYSIQUE STACK TO CART
            </button>
        `;
    } else {
        if (modeIndicator) modeIndicator.innerText = '⚡ HYBRID ENGINE';
        // Tailored Fallback generator based on goal & physique description
        let recommendedProducts = [];
        let planHtml = '';

        if (goal.includes('Hardgainer') || desc.toLowerCase().includes('skinny')) {
            recommendedProducts = [
                { id: 5, name: 'MASS GAINER PRO', price: 79.99 },
                { id: 3, name: 'CREA-PURE MAX', price: 29.99 },
                { id: 6, name: 'Z-MAX NIGHT', price: 32.00 }
            ];
            planHtml = `
                <p><strong>Physique Diagnosis:</strong> Fast ectomorph metabolism requiring high caloric density & cellular ATP hydration.</p>
                <ul style="margin:0.5rem 0 1rem 1.2rem; line-height:1.6;">
                    <li><strong>Morning / Between Meals:</strong> Take 1 serving MASS GAINER PRO (1200 kcal) for calorie surplus.</li>
                    <li><strong>Pre-Workout:</strong> 5g CREA-PURE MAX for muscle volume & power.</li>
                    <li><strong>Bedtime:</strong> 3 capsules Z-MAX NIGHT to promote deep REM sleep & growth hormone output.</li>
                </ul>
            `;
        } else if (goal.includes('Shred') || desc.toLowerCase().includes('fat')) {
            recommendedProducts = [
                { id: 1, name: 'ISO-WHEY ELITE', price: 64.99 },
                { id: 4, name: 'RECOVER BCAA+', price: 38.00 },
                { id: 7, name: 'VITA-STACK', price: 24.99 }
            ];
            planHtml = `
                <p><strong>Physique Diagnosis:</strong> Muscle preservation during caloric deficit with maximum metabolic rate.</p>
                <ul style="margin:0.5rem 0 1rem 1.2rem; line-height:1.6;">
                    <li><strong>Post-Workout:</strong> 1.5 scoops ISO-WHEY ELITE (39g protein, zero fat/sugar).</li>
                    <li><strong>Intra-Workout:</strong> 1 scoop RECOVER BCAA+ in cold water to prevent muscle breakdown.</li>
                    <li><strong>Daily Morning:</strong> 1 pack VITA-STACK for micronutrient optimal function.</li>
                </ul>
            `;
        } else {
            recommendedProducts = [
                { id: 1, name: 'ISO-WHEY ELITE', price: 64.99 },
                { id: 2, name: 'NEON FORCE PRE', price: 45.00 },
                { id: 3, name: 'CREA-PURE MAX', price: 29.99 }
            ];
            planHtml = `
                <p><strong>Physique Diagnosis:</strong> Lean hypertrophy targeting lagging muscle groups (Chest/Arms) & workout stamina.</p>
                <ul style="margin:0.5rem 0 1rem 1.2rem; line-height:1.6;">
                    <li><strong>20m Pre-Workout:</strong> 1 scoop NEON FORCE PRE for focus & vasodilation.</li>
                    <li><strong>Immediate Post-Workout:</strong> 1 scoop ISO-WHEY ELITE + 5g CREA-PURE MAX.</li>
                </ul>
            `;
        }

        outputCard.innerHTML = `
            <div style="background:rgba(236,72,153,0.08); border:1px solid rgba(236,72,153,0.3); padding:1rem; border-radius:12px; margin-bottom:1rem;">
                <div style="font-weight:900; font-family:'Rajdhani'; color:#ec4899; font-size:1rem; margin-bottom:0.5rem;">
                    💪 FITSTORE NEURAL PHYSIQUE PROTOCOL
                </div>
                ${planHtml}
            </div>
            <button onclick="${recommendedProducts.map(p => `addToCart(${p.id},1)`).join('; ')}" class="btn btn-green" style="width:100%; font-weight:900; padding:0.8rem;">
                🛒 ADD ENTIRE RECOMMENDED STACK TO CART
            </button>
        `;
    }
}

let selectedMealType = 'chicken';
function selectSampleMeal(type) {
    selectedMealType = type;
    document.querySelectorAll('.meal-sample-card').forEach(c => {
        c.style.borderColor = c.id === `meal-${type}` ? 'var(--accent)' : 'var(--card-border)';
    });
}

function runMealScanner() {
    const loading = document.getElementById('meal-scan-loading');
    const details = document.getElementById('meal-scan-details');
    if (!loading || !details) return;

    loading.style.display = 'block';
    details.style.opacity = '0.3';

    setTimeout(() => {
        loading.style.display = 'none';
        details.style.opacity = '1';
        if (selectedMealType === 'chicken') {
            document.getElementById('res-prot').innerText = '38g';
            document.getElementById('res-cal').innerText = '520 kcal';
            document.getElementById('res-rec').innerHTML = 'Meal protein is strong! Add <strong>1 Scoop of ISO-WHEY ELITE</strong> post-meal to reach peak 65g target.';
        } else {
            document.getElementById('res-prot').innerText = '18g';
            document.getElementById('res-cal').innerText = '390 kcal';
            document.getElementById('res-rec').innerHTML = 'Low meal protein detected! Add <strong>2 Scoops of ISO-WHEY ELITE</strong> to meet your anabolic threshold.';
        }
    }, 800);
}

function generateAIWorkout() {
    const goal = document.getElementById('wo-goal').value;
    const list = document.getElementById('wo-list');
    if (!list) return;

    list.innerHTML = `
        <div style="background:rgba(255,255,255,0.04); border-left:3px solid #38bdf8; padding:0.8rem; border-radius:8px;">
            <div style="font-weight:800; color:#fff; font-family:'Rajdhani'; font-size:0.95rem;">DAY 1: ${goal.toUpperCase()} - CHEST & TRICEPS</div>
            <small style="color:var(--muted);">Incline Barbell Bench (4x8) · Flat DB Flyes (3x12) · Cable Pressdown (4x12) | <strong>Pre-workout: 1 Scoop NEON FORCE PRE.</strong></small>
        </div>
        <div style="background:rgba(255,255,255,0.04); border-left:3px solid #10b981; padding:0.8rem; border-radius:8px;">
            <div style="font-weight:800; color:#fff; font-family:'Rajdhani'; font-size:0.95rem;">DAY 2: LEGS & CORE ATP OVERDRIVE</div>
            <small style="color:var(--muted);">Back Squat (5x5) · Hack Squat (3x10) · Leg Extension (4x15) | <strong>Post-workout: 1 Scoop ISO-WHEY + 5g CREA-PURE MAX.</strong></small>
        </div>
    `;
}

function applyAIBundleDiscount() {
    if (typeof applyPromoCode === 'function') {
        const input = document.getElementById('promo-code-input');
        if (input) input.value = 'FIT15';
        applyPromoCode();
    } else {
        alert('AI DISCOUNT APPLIED! Use promo code FIT15 at checkout for 15% OFF.');
    }
    closeAIConsole();
    toggleCart(true);
}

/**
 * GLOBAL FLOATING AI WIDGET LAUNCHER
 */
function ensureFloatingAIWidget() {
    if (document.getElementById('floating-ai-btn')) return;

    const widgetHTML = `
        <div id="floating-ai-btn" onclick="openAIConsole('coach')" title="Click to Launch FitStore AI Features" style="position:fixed; bottom:2rem; left:2rem; z-index:99997; display:flex; align-items:center; gap:0.6rem; background:rgba(10,17,40,0.92); border:1px solid var(--accent); padding:0.75rem 1.4rem; border-radius:50px; cursor:pointer; backdrop-filter:blur(15px); -webkit-backdrop-filter:blur(15px); box-shadow:0 10px 30px rgba(0,0,0,0.8), 0 0 25px var(--accent-glow); transition:all 0.35s cubic-bezier(0.165, 0.84, 0.44, 1);" onmouseover="this.style.transform='scale(1.08) translateY(-2px)'" onmouseout="this.style.transform='scale(1) translateY(0)'">
            <div style="width:30px; height:30px; background:linear-gradient(135deg, var(--accent) 0%, #ff8800 100%); border-radius:50%; display:flex; align-items:center; justify-content:center; color:#030712; font-size:1rem; font-weight:900;">
                <i class="fas fa-robot"></i>
            </div>
            <span style="font-family:'Rajdhani'; font-weight:900; font-size:0.95rem; color:#fff; letter-spacing:1px; display:flex; align-items:center; gap:0.4rem;">
                AI FEATURES <span style="color:var(--accent); font-size:0.75rem; background:rgba(255,107,0,0.2); border:1px solid var(--accent); padding:2px 8px; border-radius:12px; font-weight:800;">LAUNCH</span>
            </span>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', widgetHTML);
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', ensureFloatingAIWidget);
} else {
    ensureFloatingAIWidget();
}
window.addEventListener('load', ensureFloatingAIWidget);




