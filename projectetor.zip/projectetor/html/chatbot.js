/**
 * FitBot AI - FitStore Chatbot Widget
 * Uses the existing Gemini API from loader.js (getGeminiAPIKey / callGeminiAPI).
 */

const STATE = {
    isOpen: sessionStorage.getItem('cb-isOpen') === 'true',
    messages: JSON.parse(sessionStorage.getItem('cb-messages')) || [],
    context: { goals: [], discussedProducts: [] },
    hasInteracted: false,
    unreadCount: 0
};

// Base Styles
const STYLES = `
    .cb-widget { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; position: fixed; bottom: 20px; right: 20px; z-index: 9999; display: flex; flex-direction: column; align-items: flex-end; }
    .cb-bubble { background: #fff; color: #333; padding: 12px 16px; border-radius: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); margin-bottom: 15px; cursor: pointer; max-width: 250px; text-align: center; font-size: 14px; position: relative; transition: all 0.3s ease; opacity: 0; transform: translateY(10px); pointer-events: none; border: 2px solid #ff4757; }
    .cb-bubble.cb-show { opacity: 1; transform: translateY(0); pointer-events: auto; animation: cb-bounce 0.5s ease; }
    .cb-bubble:after { content: ''; position: absolute; bottom: -8px; right: 25px; border-width: 8px 8px 0; border-style: solid; border-color: #ff4757 transparent transparent transparent; display: block; width: 0; }
    .cb-bubble:before { content: ''; position: absolute; bottom: -5px; right: 27px; border-width: 6px 6px 0; border-style: solid; border-color: #fff transparent transparent transparent; display: block; width: 0; z-index: 1; }
    
    .cb-toggle { width: 60px; height: 60px; border-radius: 50%; background: linear-gradient(135deg, #ff4757, #ff6b81); color: white; display: flex; justify-content: center; align-items: center; cursor: pointer; box-shadow: 0 4px 20px rgba(255, 71, 87, 0.4); border: none; outline: none; transition: transform 0.3s ease; position: relative; }
    .cb-toggle:hover { transform: scale(1.05); }
    .cb-toggle.cb-shake { animation: cb-shake 0.8s cubic-bezier(.36,.07,.19,.97) both; }
    .cb-toggle svg { width: 30px; height: 30px; fill: white; }
    .cb-badge { position: absolute; top: -5px; right: -5px; background: #2ed573; color: white; border-radius: 50%; width: 20px; height: 20px; font-size: 12px; font-weight: bold; display: flex; justify-content: center; align-items: center; border: 2px solid white; display: none; }
    .cb-badge.cb-show { display: flex; }

    .cb-window { position: absolute; bottom: 80px; right: 0; width: 350px; height: 500px; max-height: calc(100vh - 120px); background: #ffffff; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.15); display: flex; flex-direction: column; overflow: hidden; transform-origin: bottom right; transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); opacity: 0; transform: scale(0.5); pointer-events: none; border: 1px solid #f1f2f6; }
    .cb-window.cb-open { opacity: 1; transform: scale(1); pointer-events: auto; }

    .cb-header { background: linear-gradient(135deg, #ff4757, #ff6b81); color: white; padding: 15px 20px; display: flex; align-items: center; justify-content: space-between; }
    .cb-header-info { display: flex; align-items: center; gap: 10px; }
    .cb-avatar { width: 40px; height: 40px; background: white; border-radius: 50%; display: flex; justify-content: center; align-items: center; font-size: 20px; }
    .cb-title-box { display: flex; flex-direction: column; }
    .cb-name { font-weight: bold; font-size: 16px; }
    .cb-status { font-size: 12px; opacity: 0.9; display: flex; align-items: center; gap: 4px; }
    .cb-status-dot { width: 8px; height: 8px; background: #2ed573; border-radius: 50%; display: inline-block; }
    .cb-close { background: none; border: none; color: white; font-size: 24px; cursor: pointer; opacity: 0.8; transition: opacity 0.2s; line-height: 1; }
    .cb-close:hover { opacity: 1; }

    .cb-messages { flex: 1; overflow-y: auto; padding: 20px; display: flex; flex-direction: column; gap: 12px; background: #f8f9fa; scroll-behavior: smooth; }
    .cb-msg { max-width: 80%; padding: 10px 15px; border-radius: 15px; font-size: 14px; line-height: 1.4; position: relative; word-wrap: break-word; }
    .cb-msg-bot { background: white; color: #2f3542; border-bottom-left-radius: 5px; align-self: flex-start; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
    .cb-msg-user { background: #ff4757; color: white; border-bottom-right-radius: 5px; align-self: flex-end; box-shadow: 0 2px 5px rgba(255, 71, 87, 0.2); }
    .cb-time { font-size: 10px; opacity: 0.6; margin-top: 5px; display: block; text-align: right; }

    .cb-product-card { background: #f1f2f6; border-radius: 8px; padding: 10px; margin-top: 8px; display: flex; justify-content: space-between; align-items: center; border: 1px solid #dfe4ea; }
    .cb-product-info { display: flex; flex-direction: column; }
    .cb-product-name { font-weight: bold; font-size: 13px; color: #2f3542; }
    .cb-product-price { color: #ff4757; font-weight: bold; font-size: 12px; }
    .cb-product-btn { background: #ff4757; color: white; text-decoration: none; padding: 5px 10px; border-radius: 5px; font-size: 12px; font-weight: bold; transition: background 0.2s; }
    .cb-product-btn:hover { background: #ff6b81; }

    .cb-typing { display: flex; gap: 4px; padding: 10px 15px; background: white; border-radius: 15px; border-bottom-left-radius: 5px; align-self: flex-start; box-shadow: 0 2px 5px rgba(0,0,0,0.05); display: none; }
    .cb-typing.cb-show { display: flex; }
    .cb-dot { width: 6px; height: 6px; background: #a4b0be; border-radius: 50%; animation: cb-typing-anim 1.4s infinite ease-in-out both; }
    .cb-dot:nth-child(1) { animation-delay: -0.32s; }
    .cb-dot:nth-child(2) { animation-delay: -0.16s; }

    .cb-quick-replies { display: flex; gap: 8px; overflow-x: auto; padding: 10px 20px; background: white; border-top: 1px solid #f1f2f6; flex-wrap: wrap; }
    .cb-qr-btn { background: #f1f2f6; border: 1px solid #dfe4ea; color: #2f3542; padding: 8px 12px; border-radius: 20px; font-size: 12px; cursor: pointer; transition: all 0.2s; white-space: nowrap; }
    .cb-qr-btn:hover { background: #dfe4ea; border-color: #ced6e0; transform: translateY(-1px); }

    .cb-input-area { display: flex; padding: 15px; background: white; border-top: 1px solid #f1f2f6; gap: 10px; }
    .cb-input { flex: 1; border: 1px solid #dfe4ea; border-radius: 20px; padding: 10px 15px; font-size: 14px; outline: none; transition: border-color 0.2s; }
    .cb-input:focus { border-color: #ff4757; }
    .cb-send { background: #ff4757; color: white; border: none; width: 40px; height: 40px; border-radius: 50%; display: flex; justify-content: center; align-items: center; cursor: pointer; transition: background 0.2s; }
    .cb-send:hover { background: #ff6b81; }
    .cb-send svg { width: 18px; height: 18px; fill: white; margin-left: 2px; }

    @keyframes cb-bounce { 0%, 20%, 50%, 80%, 100% { transform: translateY(0); } 40% { transform: translateY(-20px); } 60% { transform: translateY(-10px); } }
    @keyframes cb-shake { 10%, 90% { transform: translate3d(-1px, 0, 0); } 20%, 80% { transform: translate3d(2px, 0, 0); } 30%, 50%, 70% { transform: translate3d(-4px, 0, 0); } 40%, 60% { transform: translate3d(4px, 0, 0); } }
    @keyframes cb-typing-anim { 0%, 80%, 100% { transform: scale(0); } 40% { transform: scale(1); } }
`;

// HTML Structure
const WIDGET_HTML = \`
    <div class="cb-bubble" id="cb-bubble">Hey! 💪 Need help finding the perfect supplement?</div>
    
    <div class="cb-window" id="cb-window">
        <div class="cb-header">
            <div class="cb-header-info">
                <div class="cb-avatar">🤖</div>
                <div class="cb-title-box">
                    <span class="cb-name">FitBot AI</span>
                    <span class="cb-status"><span class="cb-status-dot"></span>Online</span>
                </div>
            </div>
            <button class="cb-close" id="cb-close">&times;</button>
        </div>
        
        <div class="cb-messages" id="cb-messages"></div>
        
        <div class="cb-typing" id="cb-typing">
            <div class="cb-dot"></div><div class="cb-dot"></div><div class="cb-dot"></div>
        </div>
        
        <div class="cb-quick-replies" id="cb-quick-replies"></div>
        
        <div class="cb-input-area">
            <input type="text" class="cb-input" id="cb-input" placeholder="Type your message...">
            <button class="cb-send" id="cb-send">
                <svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"></path></svg>
            </button>
        </div>
    </div>

    <button class="cb-toggle" id="cb-toggle">
        <svg viewBox="0 0 512 512"><path d="M256 32C114.6 32 0 125.1 0 240c0 49.6 19.1 94.2 51.3 131.8c-22.3 49.7-61 88.5-63.5 91c-4.3 4.3-5.3 10.8-2.6 16.1C-12 484.2-6.5 488 0 488c91.9 0 162.2-46.3 194.2-80.4c19.6 5.3 40.4 8.4 61.8 8.4c141.4 0 256-93.1 256-208S397.4 32 256 32z"/></svg>
        <div class="cb-badge" id="cb-badge">1</div>
    </button>
\`;

class FitBot {
    constructor() {
        this.injectStyles();
        this.injectHTML();
        this.cacheDOM();
        this.bindEvents();
        this.init();
    }

    injectStyles() {
        const style = document.createElement('style');
        style.textContent = STYLES;
        document.head.appendChild(style);
    }

    injectHTML() {
        const widget = document.createElement('div');
        widget.className = 'cb-widget';
        widget.innerHTML = WIDGET_HTML;
        document.body.appendChild(widget);
    }

    cacheDOM() {
        this.widget = document.querySelector('.cb-widget');
        this.bubble = document.getElementById('cb-bubble');
        this.window = document.getElementById('cb-window');
        this.toggle = document.getElementById('cb-toggle');
        this.closeBtn = document.getElementById('cb-close');
        this.messagesContainer = document.getElementById('cb-messages');
        this.typingIndicator = document.getElementById('cb-typing');
        this.qrContainer = document.getElementById('cb-quick-replies');
        this.input = document.getElementById('cb-input');
        this.sendBtn = document.getElementById('cb-send');
        this.badge = document.getElementById('cb-badge');
    }

    bindEvents() {
        this.toggle.addEventListener('click', () => this.toggleChat());
        this.closeBtn.addEventListener('click', () => this.closeChat());
        this.bubble.addEventListener('click', () => {
            this.hideBubble();
            this.openChat();
        });
        
        this.sendBtn.addEventListener('click', () => this.handleSend());
        this.input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.handleSend();
        });

        // Close on outside click
        document.addEventListener('click', (e) => {
            if (STATE.isOpen && !this.widget.contains(e.target)) {
                this.closeChat();
            }
        });

        // Scroll listener for proactive behavior
        window.addEventListener('scroll', () => {
            if (!STATE.hasInteracted && !STATE.isOpen) {
                const scrolled = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
                if (scrolled > 50 && !this.scrollBubbleShown) {
                    this.scrollBubbleShown = true;
                    this.showBubble("Seeing something you like? Let me know if you need specs! 🔍");
                }
            }
        });
    }

    init() {
        this.renderHistory();
        if (STATE.isOpen) {
            this.openChat();
        } else if (STATE.messages.length === 0) {
            this.setupProactiveTriggers();
        }

        if (STATE.unreadCount > 0 && !STATE.isOpen) {
            this.badge.textContent = STATE.unreadCount;
            this.badge.classList.add('cb-show');
        }

        this.setQuickReplies(["💪 Build Muscle", "🔥 Burn Fat", "⚡ Pre-Workout", "🥤 Protein Shakes", "📦 Track Order"]);
    }

    setupProactiveTriggers() {
        // 3s greeting
        setTimeout(() => {
            if (!STATE.hasInteracted && !STATE.isOpen) {
                this.showBubble("Hey! 💪 Need help finding the perfect supplement?");
                this.playSound();
            }
        }, 3000);

        // 15s shake & bubble
        setTimeout(() => {
            if (!STATE.hasInteracted && !STATE.isOpen) {
                this.toggle.classList.add('cb-shake');
                this.showBubble("I can recommend products based on your fitness goals! 🏋️");
                this.playSound();
                setTimeout(() => this.toggle.classList.remove('cb-shake'), 1000);
            }
        }, 15000);

        // 40s deal alert
        setTimeout(() => {
            if (!STATE.hasInteracted && !STATE.isOpen) {
                this.showBubble("🔥 Psst... I know about some exclusive deals today!");
                this.playSound();
            }
        }, 40000);

        // Idle timer (60s of no mouse movement)
        let idleTimer;
        const resetIdle = () => {
            clearTimeout(idleTimer);
            idleTimer = setTimeout(() => {
                if (!STATE.isOpen && !STATE.hasInteracted) {
                    this.showBubble("Still browsing? Let me help you find what you need! 😊");
                    this.playSound();
                }
            }, 60000);
        };
        document.addEventListener('mousemove', resetIdle);
        resetIdle();
    }

    showBubble(text) {
        this.bubble.textContent = text;
        this.bubble.classList.add('cb-show');
        this.incrementUnread();
        setTimeout(() => this.hideBubble(), 8000);
    }

    hideBubble() {
        this.bubble.classList.remove('cb-show');
    }

    toggleChat() {
        STATE.isOpen ? this.closeChat() : this.openChat();
    }

    openChat() {
        STATE.isOpen = true;
        STATE.hasInteracted = true;
        sessionStorage.setItem('cb-isOpen', 'true');
        this.window.classList.add('cb-open');
        this.hideBubble();
        this.clearUnread();
        
        if (STATE.messages.length === 0) {
            this.simulateTyping();
            setTimeout(() => {
                this.addMessage("Hi there! I'm FitBot, your personal supplement advisor. What are your fitness goals today? 🏋️", 'bot');
            }, 1000);
        }
        setTimeout(() => this.scrollToBottom(), 300);
        this.input.focus();
    }

    closeChat() {
        STATE.isOpen = false;
        sessionStorage.setItem('cb-isOpen', 'false');
        this.window.classList.remove('cb-open');
    }

    incrementUnread() {
        if (!STATE.isOpen) {
            STATE.unreadCount++;
            this.badge.textContent = STATE.unreadCount;
            this.badge.classList.add('cb-show');
        }
    }

    clearUnread() {
        STATE.unreadCount = 0;
        this.badge.classList.remove('cb-show');
    }

    handleSend() {
        const text = this.input.value.trim();
        if (!text) return;
        
        this.input.value = '';
        this.addMessage(text, 'user');
        STATE.hasInteracted = true;
        this.processResponse(text);
    }

    addMessage(text, sender, html = false) {
        const msg = { text, sender, time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}), html };
        STATE.messages.push(msg);
        sessionStorage.setItem('cb-messages', JSON.stringify(STATE.messages));
        
        this.renderMessage(msg);
        this.scrollToBottom();
        if (sender === 'bot') {
            this.playSound();
            if (!STATE.isOpen) this.incrementUnread();
        }
    }

    renderHistory() {
        STATE.messages.forEach(msg => this.renderMessage(msg));
    }

    renderMessage(msg) {
        const div = document.createElement('div');
        div.className = \`cb-msg cb-msg-\${msg.sender}\`;
        
        let content = msg.html ? msg.text : this.escapeHTML(msg.text);
        div.innerHTML = \`\${content}<span class="cb-time">\${msg.time}</span>\`;
        
        this.messagesContainer.appendChild(div);
    }

    escapeHTML(str) {
        return str.replace(/[&<>'"]/g, tag => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
        }[tag] || tag));
    }

    scrollToBottom() {
        this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
    }

    simulateTyping() {
        this.typingIndicator.classList.add('cb-show');
        this.messagesContainer.appendChild(this.typingIndicator); // Move to bottom
        this.scrollToBottom();
    }

    stopTyping() {
        this.typingIndicator.classList.remove('cb-show');
    }

    setQuickReplies(replies) {
        this.qrContainer.innerHTML = '';
        replies.forEach(reply => {
            const btn = document.createElement('button');
            btn.className = 'cb-qr-btn';
            btn.textContent = reply;
            btn.onclick = () => {
                this.input.value = reply;
                this.handleSend();
            };
            this.qrContainer.appendChild(btn);
        });
    }

    playSound() {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const osc = ctx.createOscillator();
            const gainNode = ctx.createGain();
            
            osc.type = 'sine';
            osc.frequency.setValueAtTime(880, ctx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(1760, ctx.currentTime + 0.1);
            
            gainNode.gain.setValueAtTime(0.1, ctx.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);
            
            osc.connect(gainNode);
            gainNode.connect(ctx.destination);
            
            osc.start();
            osc.stop(ctx.currentTime + 0.1);
        } catch (e) {
            // Ignore if audio context fails
        }
    }

    async processResponse(userText) {
        this.simulateTyping();
        
        const delay = Math.floor(Math.random() * (1500 - 800 + 1) + 800);
        
        // Use existing Gemini API from loader.js
        const apiKey = typeof getGeminiAPIKey === 'function' ? getGeminiAPIKey() : null;
        
        if (apiKey) {
            try {
                // Build a chatbot-specific prompt using the existing API
                const chatPrompt = `You are FitBot, FitStore's friendly AI chat assistant. Be enthusiastic, concise (2-3 sentences), use emojis, and always ask a follow-up question. User says: ${userText}`;
                const response = await callGeminiAPI(chatPrompt);
                
                if (response) {
                    setTimeout(() => {
                        this.stopTyping();
                        this.addMessage(response, 'bot', true);
                        this.updateDynamicQuickReplies(userText);
                    }, delay);
                    return;
                }
            } catch (error) {
                console.error("Gemini API Error:", error);
                // Fallback to local
            }
        }

        setTimeout(() => {
            this.stopTyping();
            this.localFallbackResponse(userText.toLowerCase());
        }, delay);
    }

    getProductCard(name, price) {
        return \`
        <div class='cb-product-card'>
            <div class='cb-product-info'>
                <span class='cb-product-name'>\${name}</span>
                <span class='cb-product-price'>$\${price}</span>
            </div>
            <a href='#' class='cb-product-btn'>View →</a>
        </div>\`;
    }

    localFallbackResponse(text) {
        let response = "";
        let qr = [];
        
        if (text.match(/hi|hello|hey/)) {
            response = "Hey there! Welcome to FitStore! 👋 Are you looking to build muscle, lose weight, or boost your energy today?";
            qr = ["💪 Build Muscle", "🔥 Burn Fat", "⚡ Boost Energy"];
        } 
        else if (text.match(/muscle|gain|bulk/)) {
            response = "Awesome goal! For building lean mass, I highly recommend our Whey Protein and Creatine. 🦍 How long have you been lifting?" + this.getProductCard("Whey Protein", "49.99") + this.getProductCard("Creatine Monohydrate", "29.99");
            qr = ["Beginner", "Intermediate", "Advanced"];
            STATE.context.goals.push('muscle');
        }
        else if (text.match(/fat|lose|cut|weight/)) {
            response = "Cutting season! 🔥 Our Fat Burner Elite is perfect for that. Pair it with a calorie deficit and you're golden. What does your current workout routine look like?" + this.getProductCard("Fat Burner Elite", "44.99");
            qr = ["Cardio mostly", "Weightlifting", "HIIT"];
            STATE.context.goals.push('fat loss');
        }
        else if (text.match(/pre|energy|workout/)) {
            response = "Need that extra push? ⚡ Our Pre-Workout Ignite delivers intense focus and pumps without the crash. Do you prefer high or moderate caffeine?" + this.getProductCard("Pre-Workout Ignite", "39.99");
            qr = ["High Caffeine", "Stim-Free", "What else?"];
        }
        else if (text.match(/recover|sore|bcaa/)) {
            response = "Recovery is where the magic happens! 🧘‍♂️ BCAAs and Omega-3s are essentials for reducing soreness. How many days a week do you train?" + this.getProductCard("BCAAs Recovery", "34.99");
            qr = ["3-4 days", "5-6 days", "Every day!"];
        }
        else if (text.match(/protein/)) {
            response = "Protein is the building block of gains! 🥩 Our Whey Protein isolates absorb super fast. Do you have any dietary restrictions?" + this.getProductCard("Whey Protein", "49.99");
            qr = ["Lactose Intolerant", "Vegan", "No restrictions"];
        }
        else if (text.match(/price|deal|discount|cheap/)) {
            response = "You're in luck! 💸 We have a 'Build Muscle Bundle' running right now. Grab Whey + Creatine and save 15%! Want me to add it to your cart?";
            qr = ["Yes, add it!", "Show me other deals", "No thanks"];
        }
        else if (text.match(/track|order|where/)) {
            response = "I can help track that for you! 📦 Please provide your 6-digit order number.";
            qr = ["I don't have it", "Talk to human"];
        }
        else {
            response = "That's awesome! Keep pushing your limits! 💯 If you need specific supplements, try browsing our categories below. What can I help you find?";
            qr = ["💪 Build Muscle", "🔥 Burn Fat", "⚡ Pre-Workout", "🥤 Protein Shakes"];
        }

        this.addMessage(response, 'bot', true);
        this.setQuickReplies(qr);
    }

    updateDynamicQuickReplies(text) {
        // Simple heuristic for dynamic quick replies based on user input
        if (text.match(/muscle|gain|bulk/i)) {
            this.setQuickReplies(["Tell me about Creatine", "Protein powder options", "How to bulk?"]);
        } else if (text.match(/fat|lose/i)) {
            this.setQuickReplies(["Fat burner details", "Diet tips", "Best cardio?"]);
        } else {
            this.setQuickReplies(["💪 Build Muscle", "🔥 Burn Fat", "⚡ Pre-Workout"]);
        }
    }
}

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    window.fitBot = new FitBot();
});
