<?php
include 'config.php';

$orderFound = false;
$orderData = null;
$error = "";

if (isset($_GET['code'])) {
    $code = trim($_GET['code']);
    if (!empty($code)) {
        if ($db_ready) {
            // Using ? for security
            $stmt = executeQuery($conn, "SELECT * FROM orders WHERE order_id_code = ?", [$code], "s");
            $result = $stmt->get_result();
            if ($orderData = $result->fetch_assoc()) {
                $orderFound = true;
            } else {
                $error = "MISSION ID NOT FOUND. Verify your code and re-attempt.";
            }
        } else {
            $error = "SATELLITE DOWNLINK OFFLINE.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FITSTORE | Tactical Dispatch Tracking</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;900&family=Rajdhani:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="themes.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <style>
        body { background: var(--bg); color: var(--text); font-family: 'Outfit', sans-serif; margin:0; min-height:100vh; }
        .hero-track { padding: 120px 0 60px; text-align: center; background: radial-gradient(circle at center, var(--accent-glow), transparent 70%); }
        .container { max-width: 800px; margin: 0 auto; padding: 0 1.5rem; }
        
        .track-box { background: var(--card); border: 1px solid var(--card-border); border-radius: 30px; padding: 3rem; backdrop-filter: blur(20px); box-shadow: var(--shadow); }
        .track-input-group { position: relative; display: flex; gap: 1rem; margin-top: 2rem; }
        .track-input { flex: 1; padding: 1.2rem; background: rgba(255,255,255,0.05); border: 1px solid var(--card-border); border-radius: 14px; color: #fff; font-family: inherit; font-size: 1.1rem; outline: none; transition: 0.3s; }
        .track-input:focus { border-color: var(--accent); background: rgba(255,107,0,0.05); }
        .btn-track { padding: 0 2rem; background: var(--accent); color: #000; border: none; border-radius: 14px; font-weight: 800; font-family: 'Rajdhani'; letter-spacing: 1px; cursor: pointer; transition: 0.3s; }
        .btn-track:hover { transform: translateY(-2px); box-shadow: 0 10px 30px var(--accent-glow); }

        /* Tracking Timeline */
        .timeline { display: flex; justify-content: space-between; position: relative; margin: 4rem 0 2rem; }
        .timeline::before { content: ''; position: absolute; top: 20px; left: 0; width: 100%; height: 2px; background: rgba(255,255,255,0.1); z-index: 1; }
        .timeline-progress { position: absolute; top: 20px; left: 0; height: 2px; background: var(--accent); z-index: 1; transition: 1s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
        
        .step { position: relative; z-index: 2; display: flex; flex-direction: column; align-items: center; gap: 1rem; width: 80px; }
        .step-dot { width: 40px; height: 40px; background: var(--card); border: 2px solid rgba(255,255,255,0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; transition: 0.5s; }
        .step.active .step-dot { background: var(--accent); border-color: var(--accent); color: #000; box-shadow: 0 0 20px var(--accent-glow); }
        .step.completed .step-dot { background: #22c55e; border-color: #22c55e; color: #fff; }
        .step-label { font-size: 0.7rem; font-weight: 800; text-transform: uppercase; color: var(--muted); }
        .step.active .step-label { color: var(--accent); }

        .order-details { margin-top: 3rem; border-top: 1px solid var(--card-border); padding-top: 2rem; text-align: left; display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; }
        .detail-item label { display: block; font-size: 0.7rem; color: var(--muted); font-weight: 700; text-transform: uppercase; margin-bottom: 0.5rem; }
        .detail-item span { font-weight: 700; color: #fff; }
    </style>
</head>
<body>

    <section class="hero-track">
        <div class="container">
            <h1 style="font-family:'Rajdhani'; font-size:3.5rem; margin:0;">ORDER <span style="color:var(--accent);">TRACKING</span></h1>
            <p style="color:var(--muted); font-weight:600;">Monitor your elite stack's journey through our global logistics grid.</p>
            
            <form action="track.php" method="GET" class="track-input-group">
                <input type="text" name="code" class="track-input" placeholder="ENTER MISSION ID (e.g. #FIT-123456)" value="<?php echo htmlspecialchars($_GET['code'] ?? ''); ?>" required>
                <button type="submit" class="btn-track">SCAN GRID</button>
            </form>
            
            <?php if ($error): ?>
                <div style="margin-top:2rem; background:rgba(239, 68, 68, 0.1); color:#ef4444; padding:1rem; border-radius:12px; border:1px solid rgba(239, 68, 68, 0.2); font-weight:700;">
                    <i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <main class="container" style="margin-top: -30px; position: relative; z-index: 10;">
        <?php if ($orderFound): 
            $statusIndex = 0;
            switch($orderData['order_status']) {
                case 'pending': $statusIndex = 0; break;
                case 'authorized': $statusIndex = 1; break;
                case 'transit': $statusIndex = 2; break;
                case 'delivered': $statusIndex = 3; break;
            }
            $progressWidth = ($statusIndex / 3) * 100;
        ?>
            <div class="track-box">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <h3 style="font-family:'Rajdhani'; margin:0;">MISSION STATUS: <span style="color:var(--accent);"><?php echo $orderData['order_id_code']; ?></span></h3>
                    <span style="font-weight:800; font-size:0.8rem; background:rgba(255,107,0,0.1); color:var(--accent); padding:0.5rem 1rem; border-radius:50px;">
                        <?php echo strtoupper($orderData['order_status']); ?>
                    </span>
                </div>

                <div class="timeline">
                    <div class="timeline-progress" style="width: <?php echo $progressWidth; ?>%;"></div>
                    
                    <div class="step <?php echo $statusIndex >= 0 ? ($statusIndex > 0 ? 'completed' : 'active') : ''; ?>">
                        <div class="step-dot"><i class="fas fa-file-invoice"></i></div>
                        <span class="step-label">PENDING</span>
                    </div>
                    <div class="step <?php echo $statusIndex >= 1 ? ($statusIndex > 1 ? 'completed' : 'active') : ''; ?>">
                        <div class="step-dot"><i class="fas fa-shield-alt"></i></div>
                        <span class="step-label">AUTH</span>
                    </div>
                    <div class="step <?php echo $statusIndex >= 2 ? ($statusIndex > 2 ? 'completed' : 'active') : ''; ?>">
                        <div class="step-dot"><i class="fas fa-truck-fast"></i></div>
                        <span class="step-label">TRANSIT</span>
                    </div>
                    <div class="step <?php echo $statusIndex >= 3 ? ($statusIndex > 3 ? 'completed' : 'active') : ''; ?>">
                        <div class="step-dot"><i class="fas fa-box-open"></i></div>
                        <span class="step-label">DEPLOYED</span>
                    </div>
                </div>

                <div class="order-details">
                    <div class="detail-item">
                        <label>OPERATIVE NAME</label>
                        <span><?php echo $orderData['customer_name']; ?></span>
                    </div>
                    <div class="detail-item">
                        <label>DROP ZONE</label>
                        <span style="font-size:0.8rem;"><?php echo $orderData['shipping_address']; ?></span>
                    </div>
                    <div class="detail-item">
                        <label>TOTAL AUTH</label>
                        <span style="color:var(--accent);">$<?php echo $orderData['total_amount']; ?></span>
                    </div>
                    <div class="detail-item">
                        <label>TIMESTAMP</label>
                        <span><?php echo date('Y-m-d H:i', strtotime($orderData['created_at'])); ?></span>
                    </div>
                </div>
            </div>
        <?php elseif (!isset($_GET['code'])): ?>
            <!-- Placeholder if no search yet -->
            <div style="text-align:center; padding: 4rem 2rem; border: 2px dashed rgba(255,255,255,0.05); border-radius: 30px; color:var(--muted);">
                <i class="fas fa-radar fa-3x" style="margin-bottom:1.5rem; opacity:0.2;"></i>
                <p style="font-weight:600;">System ready for scan. Await mission ID.</p>
            </div>
        <?php endif; ?>

        <div style="text-align:center; margin-top:3rem;">
            <a href="index.html" style="color:var(--muted); text-decoration:none; font-weight:700; font-size:0.9rem;">
                <i class="fas fa-arrow-left"></i> RETURN TO STOREFRONT
            </a>
        </div>
    </main>

    <script>
        gsap.from(".track-box", { y: 50, opacity: 0, duration: 1, ease: "power4.out" });
    </script>
</body>
</html>
