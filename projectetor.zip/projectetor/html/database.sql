-- FITSTORE DATABASE SCHEMA
-- For use with XAMPP (MySQL)

CREATE DATABASE IF NOT EXISTS fitstore_db;
USE fitstore_db;

-- 1. USERS TABLE (For Dashboard Access)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL,
    role ENUM('admin', 'agent') DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. PRODUCTS TABLE
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    image_url TEXT NOT NULL,
    description TEXT,
    servings VARCHAR(50),
    stat_label VARCHAR(50),
    stock_qty INT DEFAULT 100,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. ORDERS TABLE
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    customer_email VARCHAR(100) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    shipping_address TEXT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    order_status ENUM('pending', 'authorized', 'transit', 'delivered') DEFAULT 'authorized',
    order_id_code VARCHAR(20) UNIQUE, -- The #FIT-123456 code
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. ORDER ITEMS RELATIONAL TABLE
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT DEFAULT 1,
    unit_price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- 5. CONTACT MESSAGES TABLE
CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_name VARCHAR(100) NOT NULL,
    sender_email VARCHAR(100) NOT NULL,
    message_directive TEXT NOT NULL,
    reply_text TEXT DEFAULT NULL,
    status ENUM('unread', 'read', 'archived') DEFAULT 'unread',
    received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    replied_at TIMESTAMP NULL DEFAULT NULL
);


-- INITIAL SEED DATA FOR PRODUCTS
INSERT INTO products (name, category, price, image_url, description, servings, stat_label) VALUES
('ISO-WHEY ELITE', 'muscle', 64.99, 'https://super-eg.com/wp-content/uploads/2020/06/19465-muscletech-isowhey-ch-2000x2000-05_4b82dcfc-7922-4288-b584-fabaab4d0b50_628x.webp?_t=1734390305', 'Pure Isolate Protein for maximum muscle recovery and zero bloating.', '30', '26g Protein'),
('NEON FORCE PRE', 'energy', 45.00, 'https://chosenfewathletics.com/cdn/shop/files/PUMPTROPIC_Post.jpg?v=1772485335', 'Explosive energy and laser focus for your high-intensity workout.', '25', '300mg Caff'),
('CREA-PURE MAX', 'muscle', 29.99, 'https://neulife.com/cdn/shop/files/04_cc447695-f2a7-4093-9f4b-ebcba915e037.jpg?v=1767686530', 'Increase power output and ATP production with micronized creatine.', '60', '5g Pure'),
('RECOVER BCAA+', 'recovery', 38.00, 'https://m.media-amazon.com/images/I/81deZe5QwQL.jpg', 'Intra-workout hydration and recovery with electrolytes.', '30', '7g BCAA'),
('MASS GAINER PRO', 'muscle', 79.99, 'https://i5.walmartimages.com/seo/Optimum-Nutrition-Gold-Standard-Pro-Gainer-Protein-Powder-60-g-Protein-Vanilla-Custard-5-09-lb-14-Servings_38f00c2d-56ff-42ed-a438-9f5359c24e88.68875eddeba4d0751eba598a61051c49.jpeg', 'High-calorie formula for hard-gainers looking to pack on serious size.', '15', '1200 Cal'),
('Z-MAX NIGHT', 'recovery', 32.00, 'https://m.media-amazon.com/images/I/61kPd7IVS9L._AC_UF350,350_QL80_.jpg', 'Support recovery and sleep quality with our Zinc, Magnesium blend.', '90', 'Zinc+Mg'),
('VITA-STACK', 'energy', 24.99, 'https://preview.free3d.com/img/2021/07/3190192115036456453/gkz7ehky.jpg', 'Complete daily multivitamin optimized for high-performance athletes.', '30', '24 Vit/Min'),
('OMEGA ELITE', 'health', 35.00, 'https://m.media-amazon.com/images/I/71HK-jeLggL._AC_UF350,350_QL80_.jpg', 'High-potency fish oil for heart, brain, and joint health.', '60', '1000mg EPA');

-- DEFAULT ADMIN USER
-- Credentials: Username: admin, Email: admin@fithub.com, Password: adminakaadd
-- Note: In production, always use password_hash()
INSERT INTO users (username, password, email, role) VALUES
('admin', 'adminakaadd', 'admin@fithub.com', 'admin');

