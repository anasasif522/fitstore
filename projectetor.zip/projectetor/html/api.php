<?php
include 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit();
}

$action = $_POST['action'] ?? '';

if (!$db_ready) {
    echo json_encode(['success' => false, 'message' => 'Database connection offline.']);
    exit();
}

// --- SUBMIT CONTACT MESSAGE ---
if ($action === 'contact_submit') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $message = $_POST['message'] ?? '';

    if (empty($name) || empty($email) || empty($message)) {
        echo json_encode(['success' => false, 'message' => 'All fields are required.']);
        exit();
    }

    $stmt = executeQuery($conn, "INSERT INTO messages (sender_name, sender_email, message_directive) VALUES (?, ?, ?)", [$name, $email, $message], "sss");
    
    if ($stmt) {
        echo json_encode(['success' => true, 'message' => 'Message transmitted.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Transmission failed.']);
    }
}

// --- CHECK COMMS STATUS ---
elseif ($action === 'check_comms') {
    $email = $_POST['email'] ?? '';
    if (empty($email)) {
        echo json_encode(['success' => false, 'message' => 'Email required.']);
        exit();
    }

    $stmt = executeQuery($conn, "SELECT message_directive as message, reply_text, received_at FROM messages WHERE sender_email = ? ORDER BY received_at DESC", [$email], "s");
    $result = $stmt->get_result();
    $messages = [];
    while($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }
    echo json_encode(['success' => true, 'messages' => $messages]);
}


// --- SUBMIT ORDER ---
elseif ($action === 'order_submit') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $address = $_POST['address'] ?? '';
    $total = $_POST['total'] ?? 0;
    $cart = json_decode($_POST['cart'] ?? '[]', true);

    if (empty($name) || empty($email) || empty($phone) || empty($address) || empty($cart)) {
        echo json_encode(['success' => false, 'message' => 'Incomplete mission data.']);
        exit();
    }

    // Start Transaction
    $conn->begin_transaction();

    try {
        // 1. Create Order Code
        $orderCode = "#FIT-" . rand(100000, 999999);

        // 2. Insert Order
        $stmt = executeQuery($conn, "INSERT INTO orders (customer_name, customer_email, customer_phone, shipping_address, total_amount, order_id_code) VALUES (?, ?, ?, ?, ?, ?)", 
            [$name, $email, $phone, $address, $total, $orderCode], "ssssds");
        
        $orderId = $conn->insert_id;

        // 3. Insert Items
        foreach ($cart as $item) {
            // Check if item has product_id and price
            $pid = $item['id'] ?? null;
            $price = $item['price'] ?? 0;
            $qty = $item['qty'] ?? 1;

            if ($pid) {
                executeQuery($conn, "INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (?, ?, ?, ?)", 
                    [$orderId, $pid, $qty, $price], "iiid");
                
                // Update Stock Auto
                executeQuery($conn, "UPDATE products SET stock_qty = stock_qty - ? WHERE id = ?", [$qty, $pid], "ii");
            }
        }

        $conn->commit();
        echo json_encode(['success' => true, 'order_code' => $orderCode]);

    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'Order failed: ' . $e->getMessage()]);
    }
}

else {
    echo json_encode(['success' => false, 'message' => 'Action undefined.']);
}
?>
