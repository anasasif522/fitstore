<?php
include 'config.php';

// Auth Check
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Handle Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}

// Action Dispatcher (for automated/manual management)
$notification = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // --- Product Management ---
    if ($action === 'add_product' && $db_ready) {
        $name = $_POST['name'];
        $cat = $_POST['category'];
        $price = $_POST['price'];
        $url = $_POST['image_url'];
        $desc = $_POST['description'];
        $serv = $_POST['servings'];
        $stat = $_POST['stat_label'];

        executeQuery(
            $conn,
            "INSERT INTO products (name, category, price, image_url, description, servings, stat_label) VALUES (?,?,?,?,?,?,?)",
            [$name, $cat, $price, $url, $desc, $serv, $stat],
            "ssdssss"
        );
        $notification = "Product System Updated: $name";
    }

    if ($action === 'delete_product' && $db_ready) {
        $id = $_POST['id'];
        executeQuery($conn, "DELETE FROM products WHERE id = ?", [$id], "i");
        $notification = "Product ID $id De-listed Successfully.";
    }

    // --- Order Management ---
    if ($action === 'update_order' && $db_ready) {
        $id = $_POST['order_id'];
        $status = $_POST['status'];
        executeQuery($conn, "UPDATE orders SET order_status = ? WHERE id = ?", [$status, $id], "si");
        $notification = "Order #$id Status Updated to " . strtoupper($status);
    }

    if ($action === 'archive_message' && $db_ready) {
        $id = $_POST['id'];
        executeQuery($conn, "UPDATE messages SET status = 'archived' WHERE id = ?", [$id], "i");
        $notification = "Message Archived.";
    }

    if ($action === 'optimize_system') {
        $notification = "Mission Data Optimized. All buffers cleared.";
    }

    if ($action === 'reply_message' && $db_ready) {
        $id = $_POST['id'];
        $reply = $_POST['reply'];
        executeQuery($conn, "UPDATE messages SET reply_text = ?, status = 'read', replied_at = NOW() WHERE id = ?", [$reply, $id], "si");
        $notification = "Response Transmitted Successfully.";
    }
}
?>




<!DOCTYPE html>
<html lang="en" data-theme="dark">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FITSTORE | Mission Control Dashboard</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link
        href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;900&family=Rajdhani:wght@500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="themes.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>

    <style>
        :root {
            --sidebar-w: 260px;
        }

        body {
            font-family: 'Outfit', sans-serif;
            background: var(--bg);
            color: var(--text);
            margin: 0;
            display: flex;
            min-height: 100vh;
        }

        /* --- SIDEBAR --- */
        .sidebar {
            width: var(--sidebar-w);
            background: var(--card);
            border-right: 1px solid var(--card-border);
            padding: 2rem 1.5rem;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            backdrop-filter: blur(20px);
            z-index: 100;
        }

        .side-logo {
            font-family: 'Rajdhani', sans-serif;
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 3rem;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 2px;
        }

        .side-logo .logo-fit {
            color: var(--text);
        }

        .side-logo .logo-store {
            color: var(--accent);
            font-weight: 900;
        }

        /* --- THEME TOGGLE --- */
        .theme-toggle-admin {
            margin-top: auto;
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            background: rgba(255, 255, 255, 0.03);
            border-radius: 12px;
            cursor: pointer;
            border: 1px solid var(--card-border);
            transition: 0.3s;
        }

        .theme-toggle-admin:hover {
            background: rgba(255, 255, 255, 0.08);
            border-color: var(--accent);
        }

        .theme-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: var(--accent);
            box-shadow: 0 0 10px var(--accent-glow);
        }


        .nav-menu {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .nav-item {
            padding: 1rem 1.2rem;
            border-radius: 12px;
            color: var(--muted);
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 1rem;
            transition: 0.3s;
            font-weight: 600;
        }

        .nav-item i {
            width: 20px;
            font-size: 1.1rem;
        }

        .nav-item:hover,
        .nav-item.active {
            color: #fff;
            background: rgba(255, 107, 0, 0.1);
            border: 1px solid rgba(255, 107, 0, 0.2);
        }

        .nav-item.active {
            color: var(--accent);
        }

        /* --- SIDEBAR TOGGLE MECHANISM --- */
        body.sidebar-collapsed .sidebar {
            width: 80px;
            padding: 2rem 0.5rem;
        }

        body.sidebar-collapsed .sidebar .side-logo .logo-fit {
            display: none;
        }

        body.sidebar-collapsed .sidebar .nav-item span {
            display: none;
        }

        body.sidebar-collapsed .sidebar .nav-item {
            justify-content: center;
            padding: 1rem;
        }

        body.sidebar-collapsed .sidebar .nav-item i {
            margin: 0;
            font-size: 1.3rem;
        }

        body.sidebar-collapsed .sidebar .theme-toggle-admin {
            padding: 1rem 0;
            justify-content: center;
        }

        body.sidebar-collapsed .sidebar .theme-toggle-admin div,
        body.sidebar-collapsed .sidebar .theme-toggle-admin i:last-child {
            display: none;
        }

        body.sidebar-collapsed .main-dash {
            margin-left: 80px;
        }

        .sidebar {
            transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1), transform 0.4s ease;
        }

        .main-dash {
            transition: margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        /* --- MAIN CONTENT --- */
        .main-dash {
            flex: 1;
            margin-left: var(--sidebar-w);
            padding: 2.5rem 3rem;
        }

        /* --- ENHANCED TOP BAR --- */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 3rem;
            gap: 2rem;
            background: rgba(15, 23, 42, 0.4);
            backdrop-filter: blur(15px);
            padding: 1.2rem 2rem;
            border-radius: 20px;
            border: 1px solid var(--card-border);
            position: sticky;
            top: -20px;
            z-index: 90;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            margin-top: -2.2rem;
        }

        @media (max-width: 900px) {
            .top-bar {
                top: -40px;
                padding: 1rem;
                margin-bottom: 2rem;
                border-radius: 0 0 20px 20px;
                margin-top: -1.5rem;
            }
        }

        .search-command {
            flex: 1;
            max-width: 400px;
            position: relative;
            display: none;
            /* Visible on desktop */
        }

        @media (min-width: 1200px) {
            .search-command {
                display: block;
            }
        }

        .search-command input {
            width: 100%;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--card-border);
            padding: 0.7rem 1rem 0.7rem 2.8rem;
            border-radius: 12px;
            color: #fff;
            outline: none;
            transition: 0.3s;
            font-size: 0.85rem;
        }

        .search-command input:focus {
            border-color: var(--accent);
            background: rgba(255, 255, 255, 0.1);
        }

        .search-command i {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--muted);
            font-size: 0.9rem;
        }

        .hamburger-trigger {
            width: 45px;
            height: 45px;
            background: var(--card);
            border: 1px solid var(--card-border);
            border-radius: 12px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            gap: 4px;
            cursor: pointer;
            transition: 0.3s;
        }

        .hamburger-trigger:hover {
            border-color: var(--accent);
            background: rgba(255, 107, 0, 0.05);
        }

        .hamburger-trigger span {
            width: 20px;
            height: 2px;
            background: var(--accent);
            border-radius: 2px;
            transition: 0.3s;
        }

        .hamburger-trigger:hover span:nth-child(2) {
            width: 12px;
        }

        .page-title h1 {
            font-family: 'Rajdhani', sans-serif;
            font-size: 2.2rem;
            font-weight: 700;
            margin: 0;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .admin-meta {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .top-clock {
            font-family: 'Rajdhani', sans-serif;
            font-weight: 700;
            color: var(--accent);
            letter-spacing: 1px;
            font-size: 1rem;
            display: none;
        }

        @media (min-width: 768px) {
            .top-clock {
                display: block;
            }
        }

        .db-status {
            padding: 0.4rem 1rem;
            border-radius: 50px;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
        }

        .db-status.online {
            background: rgba(34, 197, 94, 0.1);
            color: #22c55e;
            border: 1px solid rgba(34, 197, 94, 0.2);
        }

        .db-status.offline {
            background: rgba(239, 68, 68, 0.1);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        /* --- STAT CARDS --- */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 1.5rem;
            margin-bottom: 3rem;
        }

        .stat-card {
            background: var(--card);
            border: 1px solid var(--card-border);
            padding: 2rem;
            border-radius: 24px;
            transition: 0.3s;
            position: relative;
            overflow: hidden;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            border-color: var(--accent);
        }

        .stat-card .label {
            color: var(--muted);
            font-size: 0.85rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .stat-card .value {
            font-family: 'Rajdhani', sans-serif;
            font-size: 2.5rem;
            font-weight: 700;
            margin-top: 0.5rem;
            color: #fff;
        }

        .stat-card i {
            position: absolute;
            right: 1.5rem;
            top: 50%;
            transform: translateY(-50%);
            font-size: 3rem;
            opacity: 0.05;
            color: var(--accent);
        }

        /* --- TABLES --- */
        .dash-row {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
        }

        .content-box {
            background: var(--card);
            border: 1px solid var(--card-border);
            border-radius: 24px;
            padding: 2rem;
            backdrop-filter: blur(10px);
        }

        .box-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .box-header h3 {
            font-family: 'Rajdhani', sans-serif;
            font-size: 1.4rem;
            margin: 0;
        }

        .btn-sm {
            padding: 0.5rem 1rem;
            border-radius: 8px;
            background: rgba(255, 107, 0, 0.1);
            color: var(--accent);
            text-decoration: none;
            font-size: 0.8rem;
            font-weight: 700;
            border: 1px solid rgba(255, 107, 0, 0.2);
            transition: 0.3s;
        }

        .btn-sm:hover {
            background: var(--accent);
            color: #000;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 1rem;
            color: var(--accent);
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-bottom: 1px solid var(--card-border);
        }

        td {
            padding: 1.2rem 1rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.03);
            font-size: 0.9rem;
        }

        .table-responsive {
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .table-responsive table {
            min-width: 600px;
        }

        .status-pill {
            padding: 0.3rem 0.8rem;
            border-radius: 50px;
            font-size: 0.7rem;
            font-weight: 700;
            text-transform: uppercase;
        }

        .status-pill.auth {
            background: rgba(255, 107, 0, 0.1);
            color: var(--accent);
        }

        .table-wrap {
            overflow-x: auto;
            width: 100%;
        }

        table {
            min-width: 600px;
        }


        /* --- NOTIFICATION TOAST --- */
        #notification-toast {
            position: fixed;
            bottom: 2rem;
            right: 2rem;
            background: #fff;
            color: #000;
            padding: 1rem 1.5rem;
            border-radius: 12px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 1rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            z-index: 1000;
            transform: translateY(100px);
            opacity: 0;
            transition: 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        #notification-toast.show {
            transform: translateY(0);
            opacity: 1;
        }

        /* --- MODAL --- */
        .modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(10px);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 2000;
        }

        .modal-content {
            background: var(--card);
            border: 1px solid var(--card-border);
            padding: 2.5rem;
            border-radius: 30px;
            width: 90%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
        }

        .form-row {
            margin-bottom: 1.2rem;
        }

        .form-row label {
            display: block;
            color: var(--muted);
            font-size: 0.75rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            text-transform: uppercase;
        }

        .form-row input,
        .form-row select,
        .form-row textarea {
            width: 100%;
            padding: 0.8rem;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--card-border);
            border-radius: 10px;
            color: #fff;
            font-family: inherit;
        }

        .stock-pill {
            padding: 0.2rem 0.6rem;
            border-radius: 5px;
            font-size: 0.7rem;
            font-weight: 800;
        }

        .stock-pill.low {
            background: rgba(239, 68, 68, 0.1);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .stock-pill.ok {
            background: rgba(34, 197, 94, 0.1);
            color: #22c55e;
            border: 1px solid rgba(34, 197, 94, 0.2);
        }

        @media (max-width: 1100px) {
            .dash-row {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 900px) {
            :root {
                --sidebar-w: 0px;
            }

            body {
                flex-direction: column;
            }

            .sidebar {
                width: 280px;
                transform: translateX(-100%);
                transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
                box-shadow: 20px 0 50px rgba(0, 0, 0, 0.5);
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .main-dash {
                margin-left: 0;
                padding: 1.5rem;
                padding-top: 5rem;
            }

            .mobile-header {
                display: none !important;
            }

            .top-bar {
                flex-direction: column;
                align-items: flex-start;
                gap: 1.5rem;
            }

            .admin-meta {
                width: 100%;
                justify-content: space-between;
            }

            .stats-grid {
                grid-template-columns: 1fr;
                gap: 1rem;
            }

            .content-box {
                padding: 1.5rem;
            }

            .page-title h1 {
                font-size: 1.6rem;
            }

            .modal-content {
                padding: 1.5rem;
                width: 95%;
            }
        }

        /* Removed old mobile-header */

        .hamburger-admin {
            width: 30px;
            height: 20px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            cursor: pointer;
        }

        .hamburger-admin span {
            width: 100%;
            height: 2px;
            background: var(--accent);
            border-radius: 2px;
            transition: 0.3s;
        }

        .close-sidebar {
            display: none;
            position: absolute;
            right: 1.5rem;
            top: 2rem;
            font-size: 1.5rem;
            color: var(--muted);
            cursor: pointer;
        }

        @media (max-width: 900px) {
            .close-sidebar {
                display: block;
            }
        }

        /* High-Density & Extra Mobile Refinements */
        @media (max-width: 600px) {
            .main-dash {
                padding: 0.8rem;
                padding-top: 4.5rem;
            }

            .content-box {
                padding: 1rem;
                border-radius: 16px;
            }

            .stat-card {
                padding: 1.2rem;
                border-radius: 16px;
            }

            .stat-card .value {
                font-size: 1.8rem;
            }

            .top-bar {
                margin-bottom: 1.5rem;
                gap: 0.8rem;
            }

            .page-title h1 {
                font-size: 1.3rem;
            }

            .admin-meta {
                flex-wrap: wrap;
                gap: 0.5rem;
            }

            .db-status {
                font-size: 0.65rem;
                padding: 0.3rem 0.8rem;
            }

            /* Table optimization for absolute small screens */
            td {
                padding: 0.7rem 0.5rem;
                font-size: 0.75rem;
            }

            th {
                padding: 0.7rem 0.5rem;
                font-size: 0.6rem;
            }

            .box-header h3 {
                font-size: 1.1rem;
            }

            .modal-content .grid-2-col {
                grid-template-columns: 1fr !important;
                gap: 0.5rem !important;
            }
        }

        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(8px);
            z-index: 99;
            display: none;
            opacity: 0;
            transition: 0.4s;
            cursor: pointer;
        }

        .sidebar-overlay.active {
            display: block;
            opacity: 1;
        }

        /* --- DASHBOARD FOOTER --- */
        .dash-footer {
            margin-top: 4rem;
            padding: 2rem 0;
            border-top: 1px solid var(--card-border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: var(--muted);
            font-size: 0.8rem;
        }

        @media (max-width: 600px) {
            .dash-footer {
                flex-direction: column;
                gap: 1.5rem;
                text-align: center;
            }
        }

        .system-health {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .health-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .health-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #22c55e;
            box-shadow: 0 0 10px rgba(34, 197, 148, 0.5);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% {
                opacity: 1;
            }

            50% {
                opacity: 0.4;
            }

            100% {
                opacity: 1;
            }
        }
    </style>

</head>

<body>

    <div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>

    <aside class="sidebar" id="sidebar">
        <div class="close-sidebar" onclick="toggleSidebar(false)">&times;</div>
        <a href="admin.php" class="side-logo">
            <span class="logo-fit">FIT</span><span class="logo-store">STORE</span>
        </a>


        <?php $view = $_GET['view'] ?? 'dash'; ?>
        <div class="nav-menu">
            <a href="admin.php?view=dash" class="nav-item <?php echo $view == 'dash' ? 'active' : ''; ?>"><i
                    class="fas fa-th-large"></i> <span>DASHBOARD</span></a>
            <a href="admin.php?view=orders" class="nav-item <?php echo $view == 'orders' ? 'active' : ''; ?>"><i
                    class="fas fa-shopping-cart"></i> <span>ORDERS</span></a>
            <a href="admin.php?view=inventory" class="nav-item <?php echo $view == 'inventory' ? 'active' : ''; ?>"><i
                    class="fas fa-box"></i> <span>INVENTORY</span></a>
            <a href="admin.php?view=messages" class="nav-item <?php echo $view == 'messages' ? 'active' : ''; ?>"><i
                    class="fas fa-envelope"></i> <span>MESSAGES</span></a>
            <a href="admin.php?view=agents" class="nav-item <?php echo $view == 'agents' ? 'active' : ''; ?>"><i
                    class="fas fa-users"></i> <span>AGENTS</span></a>
            <a href="admin.php?view=settings" class="nav-item <?php echo $view == 'settings' ? 'active' : ''; ?>"
                style="margin-top: 3rem;"><i class="fas fa-cog"></i> <span>SETTINGS</span></a>
            <a href="admin.php?logout=1" class="nav-item" style="color:#ef4444;"><i class="fas fa-sign-out-alt"></i>
                <span>LOGOUT</span></a>
        </div>

        <div class="theme-toggle-admin" onclick="cycleTheme()">
            <div class="theme-dot"></div>
            <div style="flex:1;">
                <div style="font-size:0.7rem; color:var(--muted); font-weight:700; text-transform:uppercase;">Theme Mode
                </div>
                <div id="active-theme-label" style="font-size:0.8rem; font-weight:700;">DARK PROTOCOL</div>
            </div>
            <i class="fas fa-sync-alt" style="font-size:0.8rem; opacity:0.5;"></i>
        </div>
    </aside>


    <main class="main-dash">
        <div class="top-bar">
            <div style="display:flex; align-items:center; gap:1.5rem;">
                <div class="page-title">
                    <small style="color:var(--muted); font-weight:700; font-size:0.7rem;">COMMAND CENTER V1.0 -
                        <?php echo strtoupper($view); ?></small>
                    <h1><?php
                    switch ($view) {
                        case 'inventory':
                            echo "Inventory Matrix";
                            break;
                        case 'orders':
                            echo "Logistics Control";
                            break;
                        case 'messages':
                            echo "Comms Channel";
                            break;
                        case 'agents':
                            echo "Personnel Database";
                            break;
                        case 'settings':
                            echo "Kernel Config";
                            break;
                        default:
                            echo "Mission Control";
                    }
                    ?></h1>
                </div>
            </div>

            <div class="search-command">
                <i class="fas fa-search"></i>
                <input type="text" placeholder="Search Command (Press '/' to focus)...">
            </div>

            <div class="admin-meta">
                <div class="top-clock" id="liveClock">00:00:00 UTC</div>
                <span class="db-status <?php echo $db_ready ? 'online' : 'offline'; ?>">
                    <?php echo $db_ready ? 'LIVE SYSTEM' : 'OFFLINE MODE'; ?>
                </span>
                <div style="display:flex; align-items:center; gap:0.8rem;">
                    <span
                        style="font-weight:700; font-size:0.9rem;"><?php echo strtoupper($_SESSION['admin_user']); ?></span>
                    <img src="https://ui-avatars.com/api/?name=<?php echo $_SESSION['admin_user']; ?>&background=ff6b00&color=000"
                        style="width:40px; border-radius:50%;">
                </div>

                <div class="hamburger-trigger" onclick="toggleSidebar()">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>

        <?php if ($view == 'dash'): ?>
            <!-- DASHBOARD VIEW -->
            <section class="stats-grid">
                <div class="stat-card reveal">
                    <div class="label">Total Dispatch</div>
                    <div class="value">
                        <?php
                        if ($db_ready) {
                            $res = $conn->query("SELECT COUNT(*) as count FROM orders");
                            echo $res->fetch_assoc()['count'];
                        } else
                            echo "128";
                        ?>
                    </div>
                </div>
                <div class="stat-card reveal">
                    <div class="label">Revenue (USD)</div>
                    <div class="value">
                        <?php
                        if ($db_ready) {
                            $res = $conn->query("SELECT SUM(total_amount) as total FROM orders");
                            echo "$" . number_format($res->fetch_assoc()['total'] ?? 0, 2);
                        } else
                            echo "$8,452.20";
                        ?>
                    </div>
                </div>
                <div class="stat-card reveal">
                    <div class="label">Low Stock Alerts</div>
                    <div class="value">
                        <?php
                        if ($db_ready) {
                            $res = $conn->query("SELECT COUNT(*) as count FROM products WHERE stock_qty < 10");
                            echo $res->fetch_assoc()['count'];
                        } else
                            echo "0";
                        ?>
                    </div>
                </div>
            </section>

            <section class="dash-row">
                <div class="content-box reveal">
                    <div class="box-header">
                        <h3>Recent Authorizations</h3>
                        <a href="admin.php?view=orders" class="btn-sm">VIEW ALL</a>
                    </div>
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>ORDER</th>
                                    <th>CLIENT</th>
                                    <th>STATUS</th>
                                    <th>TOTAL</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($db_ready):
                                    $orders = $conn->query("SELECT * FROM orders ORDER BY created_at DESC LIMIT 5");
                                    while ($o = $orders->fetch_assoc()): ?>
                                        <tr>
                                            <td style="color:var(--accent); font-weight:700;"><?php echo $o['order_id_code']; ?>
                                            </td>
                                            <td><?php echo $o['customer_name']; ?></td>
                                            <td><span class="status-pill auth"><?php echo strtoupper($o['order_status']); ?></span>
                                            </td>
                                            <td>$<?php echo $o['total_amount']; ?></td>
                                        </tr>
                                    <?php endwhile; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="content-box reveal">
                    <div class="box-header">
                        <h3>Critical Stock</h3>
                        <a href="admin.php?view=inventory" class="btn-sm">MANAGE</a>
                    </div>
                    <?php if ($db_ready):
                        $prods = $conn->query("SELECT * FROM products WHERE stock_qty < 15 LIMIT 5");
                        while ($p = $prods->fetch_assoc()): ?>
                            <div style="display:flex; align-items:center; gap:1rem; margin-bottom:1rem;">
                                <img src="<?php echo $p['image_url']; ?>"
                                    style="width:40px; height:40px; border-radius:8px; object-fit:contain; background:#000;">
                                <div style="flex:1;">
                                    <div style="font-weight:700; font-size:0.9rem;"><?php echo $p['name']; ?></div>
                                    <div class="stock-pill low"><?php echo $p['stock_qty']; ?> LEFT</div>
                                </div>
                            </div>
                        <?php endwhile; endif; ?>
                </div>
            </section>

        <?php elseif ($view == 'inventory'): ?>
            <!-- INVENTORY VIEW -->
            <div class="content-box reveal">
                <div class="box-header">
                    <h3>Asset Management</h3>
                    <button class="btn-sm" onclick="openModal('productModal')">ADD NEW PRODUCT</button>
                </div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>IMAGE</th>
                                <th>PRODUCT</th>
                                <th>CATEGORY</th>
                                <th>PRICE</th>
                                <th>STOCK</th>
                                <th>ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($db_ready):
                                $prods = $conn->query("SELECT * FROM products ORDER BY created_at DESC");
                                while ($p = $prods->fetch_assoc()): ?>
                                    <tr>
                                        <td><img src="<?php echo $p['image_url']; ?>"
                                                style="width:40px; border-radius:5px; background:#000;"></td>
                                        <td style="font-weight:700;"><?php echo $p['name']; ?></td>
                                        <td><?php echo strtoupper($p['category']); ?></td>
                                        <td>$<?php echo $p['price']; ?></td>
                                        <td>
                                            <span class="stock-pill <?php echo $p['stock_qty'] < 10 ? 'low' : 'ok'; ?>">
                                                <?php echo $p['stock_qty']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <form method="POST" style="display:inline;"
                                                onsubmit="return confirm('De-list this asset?');">
                                                <input type="hidden" name="action" value="delete_product">
                                                <input type="hidden" name="id" value="<?php echo $p['id']; ?>">
                                                <button type="submit"
                                                    style="background:none; border:none; color:#ef4444; cursor:pointer;"><i
                                                        class="fas fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        <?php elseif ($view == 'orders'): ?>
            <!-- ORDERS VIEW -->
            <div class="content-box reveal">
                <div class="box-header">
                    <h3>Logistics Tracking</h3>
                </div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>CODE</th>
                                <th>CUSTOMER</th>
                                <th>ADDRESS</th>
                                <th>STATUS</th>
                                <th>CHANGE STATUS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($db_ready):
                                $orders = $conn->query("SELECT * FROM orders ORDER BY created_at DESC");
                                while ($o = $orders->fetch_assoc()): ?>
                                    <tr>
                                        <td style="color:var(--accent); font-weight:700;"><?php echo $o['order_id_code']; ?></td>
                                        <td><?php echo $o['customer_name']; ?><br><small><?php echo $o['customer_email']; ?></small>
                                        </td>
                                        <td style="font-size:0.75rem; max-width:150px;"><?php echo $o['shipping_address']; ?></td>
                                        <td><span class="status-pill auth"><?php echo strtoupper($o['order_status']); ?></span></td>
                                        <td>
                                            <form method="POST">
                                                <input type="hidden" name="action" value="update_order">
                                                <input type="hidden" name="order_id" value="<?php echo $o['id']; ?>">
                                                <select name="status" onchange="this.form.submit()"
                                                    style="padding:0.3rem; border-radius:5px; background:#111; color:#fff; border:1px solid #333; font-size:0.75rem;">
                                                    <option value="pending" <?php echo $o['order_status'] == 'pending' ? 'selected' : ''; ?>>PENDING</option>
                                                    <option value="authorized" <?php echo $o['order_status'] == 'authorized' ? 'selected' : ''; ?>>AUTHORIZED</option>
                                                    <option value="transit" <?php echo $o['order_status'] == 'transit' ? 'selected' : ''; ?>>TRANSIT</option>
                                                    <option value="delivered" <?php echo $o['order_status'] == 'delivered' ? 'selected' : ''; ?>>DELIVERED</option>
                                                </select>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php elseif ($view == 'messages'): ?>
            <!-- MESSAGES VIEW -->
            <div class="content-box reveal">
                <div class="box-header">
                    <h3>Communication Comms</h3>
                </div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>SENDER</th>
                                <th>MESSAGE</th>
                                <th>RECEIVED</th>
                                <th>STATUS</th>
                                <th>ACTION</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($db_ready):
                                $msgs = $conn->query("SELECT * FROM messages ORDER BY received_at DESC");
                                while ($m = $msgs->fetch_assoc()): ?>
                                    <tr style="<?php echo $m['status'] == 'unread' ? 'background:rgba(255,107,0,0.03);' : ''; ?>">
                                        <td><strong><?php echo $m['sender_name']; ?></strong><br><small><?php echo $m['sender_email']; ?></small>
                                        </td>
                                        <td style="max-width:300px;"><?php echo $m['message_directive']; ?></td>
                                        <td><?php echo date('M d, H:i', strtotime($m['received_at'])); ?></td>
                                        <td><span
                                                class="status-pill <?php echo $m['status'] == 'unread' ? 'auth' : ''; ?>"><?php echo strtoupper($m['status']); ?></span>
                                        </td>
                                        <td>
                                            <div style="display:flex; gap:0.5rem;">
                                                <button class="btn-sm"
                                                    style="background:rgba(255,107,0,0.1); border:1px solid var(--accent); color:var(--accent); cursor:pointer;"
                                                    onclick="openReplyModal(<?php echo $m['id']; ?>, '<?php echo addslashes($m['sender_name']); ?>', '<?php echo addslashes($m['message_directive']); ?>')">REPLY</button>
                                                <form method="POST" style="display:inline;">
                                                    <input type="hidden" name="action" value="archive_message">
                                                    <input type="hidden" name="id" value="<?php echo $m['id']; ?>">
                                                    <button type="submit"
                                                        style="background:none; border:none; color:var(--muted); cursor:pointer;"><i
                                                            class="fas fa-archive"></i></button>
                                                </form>
                                            </div>
                                            <?php if ($m['reply_text']): ?>
                                                <div
                                                    style="margin-top:0.5rem; font-size:0.75rem; color:var(--accent); font-style:italic;">
                                                    Replied: "<?php echo substr($m['reply_text'], 0, 30); ?>..."
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endwhile; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>


        <?php elseif ($view == 'agents'): ?>
            <!-- AGENTS VIEW -->
            <div class="content-box reveal">
                <div class="box-header">
                    <h3>Active Operatives</h3>
                </div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>IDENTITY</th>
                                <th>EMAIL</th>
                                <th>ROLE</th>
                                <th>JOINED</th>
                                <th>STATUS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($db_ready):
                                $users = $conn->query("SELECT * FROM users");
                                while ($u = $users->fetch_assoc()): ?>
                                    <tr>
                                        <td style="font-weight:700;"><i class="fas fa-user-secret"
                                                style="margin-right:0.5rem; opacity:0.5;"></i><?php echo strtoupper($u['username']); ?>
                                        </td>
                                        <td><?php echo $u['email']; ?></td>
                                        <td><span class="status-pill auth"><?php echo strtoupper($u['role']); ?></span></td>
                                        <td><?php echo date('Y-m-d', strtotime($u['created_at'])); ?></td>
                                        <td><span class="stock-pill ok">ACTIVE</span></td>
                                    </tr>
                                <?php endwhile; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php elseif ($view == 'settings'): ?>
            <!-- SETTINGS VIEW -->
            <div class="dash-row reveal">
                <div class="content-box">
                    <h3>Command Security Audit</h3>
                    <div style="margin-top: 2rem;">
                        <div
                            style="display:flex; justify-content:space-between; margin-bottom:1rem; padding:1rem; background:rgba(255,107,0,0.05); border-radius:12px; border:1px solid var(--card-border);">
                            <span>Session Integrity</span>
                            <span style="color:#22c55e; font-weight:700;">ENCRYPTED</span>
                        </div>
                        <div
                            style="display:flex; justify-content:space-between; margin-bottom:1rem; padding:1rem; background:rgba(255,107,0,0.05); border-radius:12px; border:1px solid var(--card-border);">
                            <span>Database Ingress Protection</span>
                            <span style="color:#22c55e; font-weight:700;">ACTIVE (PREPARED)</span>
                        </div>
                        <div
                            style="display:flex; justify-content:space-between; margin-bottom:1rem; padding:1rem; background:rgba(255,107,0,0.05); border-radius:12px; border:1px solid var(--card-border);">
                            <span>XSS Filtration</span>
                            <span style="color:#22c55e; font-weight:700;">ENABLED</span>
                        </div>
                    </div>
                </div>

                <div class="content-box">
                    <h3>System Automation</h3>
                    <p style="color:var(--muted); font-size:0.8rem;">Automated maintenance tasks for mission endurance.</p>
                    <form method="POST">
                        <input type="hidden" name="action" value="optimize_system">
                        <button type="submit" class="btn-sm" style="width:100%; padding:1rem; margin-top:1rem;">RUN GLOBAL
                            OPTIMIZATION</button>
                    </form>
                    <div style="margin-top:1.5rem; font-size:0.7rem; color:var(--muted); text-align:center;">
                        Next automated sweep: 04:00 AM
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <footer class="dash-footer">
            <div class="system-health">
                <div class="health-item">
                    <div class="health-dot"></div>
                    <span>SYSTEM CORE STABLE</span>
                </div>
                <div class="health-item" style="display:none; md:block;">
                    <i class="fas fa-satellite" style="font-size:0.7rem;"></i>
                    <span>SAT-LINK: ACTIVE</span>
                </div>
                <div class="health-item">
                    <i class="fas fa-microchip" style="font-size:0.7rem;"></i>
                    <span>UPTIME: 99.9%</span>
                </div>
            </div>

            <div style="text-align:right;">
                <div style="font-weight:700; color:#fff;">FITSTORE &copy; <?php echo date('Y'); ?> MISSION CONTROL</div>
                <div style="font-size:0.65rem; color:var(--muted); text-transform:uppercase; letter-spacing:1px;">
                    Encrypted Data Channel 04-X99</div>
            </div>
        </footer>

    </main>


    <!-- PRODUCT MODAL -->
    <div id="productModal" class="modal">
        <div class="modal-content">
            <h3 style="font-family:'Rajdhani'; margin-top:0;">INITIALIZE NEW ASSET</h3>
            <form method="POST">
                <input type="hidden" name="action" value="add_product">
                <div class="form-row">
                    <label>Product Name</label>
                    <input type="text" name="name" required>
                </div>
                <div class="grid-2-col" style="display:grid; grid-template-columns: 1fr 1fr; gap:1rem;">
                    <div class="form-row">
                        <label>Category</label>
                        <select name="category">
                            <option value="muscle">Muscle</option>
                            <option value="energy">Energy</option>
                            <option value="recovery">Recovery</option>
                            <option value="health">Health</option>
                        </select>
                    </div>
                    <div class="form-row">
                        <label>Price (USD)</label>
                        <input type="number" step="0.01" name="price" required>
                    </div>
                </div>
                <div class="form-row">
                    <label>Image URL</label>
                    <input type="text" name="image_url" placeholder="https://..." required>
                </div>
                <div class="grid-2-col" style="display:grid; grid-template-columns: 1fr 1fr; gap:1rem;">
                    <div class="form-row">
                        <label>Servings</label>
                        <input type="text" name="servings" placeholder="e.g. 30">
                    </div>
                    <div class="form-row">
                        <label>Stat Label</label>
                        <input type="text" name="stat_label" placeholder="e.g. 25g Protein">
                    </div>
                </div>
                <div class="form-row">
                    <label>Description</label>
                    <textarea name="description" rows="3"></textarea>
                </div>
                <div style="display:flex; gap:1rem; margin-top:2rem;">
                    <button type="submit" class="btn-sm" style="flex:1; padding:1rem;">COMMENCE UPLOAD</button>
                    <button type="button" class="btn-sm" style="background:#222; border-color:#444;"
                        onclick="closeModal('productModal')">ABORT</button>
                </div>
            </form>
        </div>
    </div>

    <!-- NOTIFICATION TOAST -->
    <div id="notification-toast">
        <i class="fas fa-check-circle" style="color:#22c55e;"></i>
        <span id="toast-msg"><?php echo $notification; ?></span>
    </div>


    <!-- REPLY MODAL -->
    <div id="replyModal" class="modal">
        <div class="modal-content">
            <h3 style="font-family:'Rajdhani'; margin-top:0;">SECURE COMMS UPLINK</h3>
            <p id="reply-msg-preview"
                style="background:#111; padding:1rem; border-radius:10px; font-size:0.8rem; border-left:3px solid var(--accent); white-space:pre-wrap;">
            </p>
            <form method="POST">
                <input type="hidden" name="action" value="reply_message">
                <input type="hidden" name="id" id="reply-msg-id">
                <div class="form-row">
                    <label>Admin Response (Directive)</label>
                    <textarea name="reply" rows="5" required placeholder="Type your response here..."></textarea>
                </div>
                <div style="display:flex; gap:1rem; margin-top:2rem;">
                    <button type="submit" class="btn-sm" style="flex:1; padding:1rem;">TRANSMIT REPLY</button>
                    <button type="button" class="btn-sm" style="background:#222; border-color:#444;"
                        onclick="closeModal('replyModal')">CANCEL</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function toggleSidebar(forceState = null) {
            const body = document.body;
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebarOverlay');
            const isMobile = window.innerWidth <= 900;

            if (isMobile) {
                const isCurrentlyActive = sidebar.classList.contains('active');
                const shouldBeActive = forceState !== null ? forceState : !isCurrentlyActive;

                if (!shouldBeActive) {
                    sidebar.classList.remove('active');
                    overlay.classList.remove('active');
                    setTimeout(() => { if (!sidebar.classList.contains('active')) overlay.style.display = 'none'; }, 400);
                } else {
                    sidebar.classList.add('active');
                    overlay.style.display = 'block';
                    setTimeout(() => overlay.classList.add('active'), 10);
                }
            } else {
                body.classList.toggle('sidebar-collapsed');
                localStorage.setItem('admin-sidebar-collapsed', body.classList.contains('sidebar-collapsed'));
            }
        }

        const themes = ['dark', 'light-green', 'light-blue', 'light-orange', 'light-purple', 'light-minimal'];
        let currentThemeIdx = 0;

        function cycleTheme() {
            currentThemeIdx = (currentThemeIdx + 1) % themes.length;
            const newTheme = themes[currentThemeIdx];
            document.documentElement.setAttribute('data-theme', newTheme);
            document.getElementById('active-theme-label').innerText = newTheme.replace('-', ' ').toUpperCase();
            localStorage.setItem('admin-theme', newTheme);
        }

        // Load saved theme
        const savedTheme = localStorage.getItem('admin-theme');
        if (savedTheme) {
            document.documentElement.setAttribute('data-theme', savedTheme);
            currentThemeIdx = themes.indexOf(savedTheme);
            if (currentThemeIdx === -1) currentThemeIdx = 0;
            document.getElementById('active-theme-label').innerText = themes[currentThemeIdx].replace('-', ' ').toUpperCase();
        }

        // Live Clock
        function updateClock() {
            const now = new Date();
            const timeStr = now.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
            document.getElementById('liveClock').innerText = timeStr + " UTC";
        }
        setInterval(updateClock, 1000);
        updateClock();

        // Global Search Focus Shortcut
        window.addEventListener('keydown', (e) => {
            if (e.key === '/') {
                const search = document.querySelector('.search-command input');
                if (document.activeElement !== search) {
                    e.preventDefault();
                    search.focus();
                }
            }
        });

        function openReplyModal(id, sender, msg) {
            document.getElementById('reply-msg-id').value = id;
            document.getElementById('reply-msg-preview').innerText = "FROM: " + sender.toUpperCase() + "\n\n" + msg;
            openModal('replyModal');
        }

        // Apply saved collapse state on desktop
        if (localStorage.getItem('admin-sidebar-collapsed') === 'true' && window.innerWidth > 900) {
            document.body.classList.add('sidebar-collapsed');
        }

        gsap.from(".reveal", {
            y: 40,
            opacity: 0,
            duration: 1,
            stagger: 0.2,
            ease: "power3.out",
            delay: 0.1
        });

        // Modal Controls
        function openModal(id) {
            document.getElementById(id).style.display = 'flex';
            gsap.from("#" + id + " .modal-content", { y: 50, opacity: 0, duration: 0.5 });
        }

        function closeModal(id) {
            gsap.to("#" + id + " .modal-content", {
                y: 50, opacity: 0, duration: 0.3, onComplete: () => {
                    document.getElementById(id).style.display = 'none';
                }
            });
        }

        // Notification System
        <?php if ($notification): ?>
            const toast = document.getElementById('notification-toast');
            toast.classList.add('show');
            setTimeout(() => toast.classList.remove('show'), 5000);
        <?php endif; ?>
    </script>

</body>

</html>