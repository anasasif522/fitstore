<?php
include 'config.php';

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($db_ready) {
        // Auto-Seed: Ensure the requested admin exists (Automation Feature)
        $check = $conn->query("SELECT id FROM users WHERE email = 'admin@fithub.com'");
        if ($check && $check->num_rows === 0) {
            $conn->query("INSERT INTO users (username, password, email, role) VALUES ('admin', 'adminakaadd', 'admin@fithub.com', 'admin')");
        }

        $stmt = executeQuery($conn, "SELECT id, password, role FROM users WHERE username = ? OR email = ?", [$username, $username], "ss");
        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {
            if ($password === $user['password'] || password_verify($password, $user['password'])) {
                $_SESSION['admin_id'] = $user['id'];
                $_SESSION['admin_user'] = 'admin';
                $_SESSION['admin_role'] = $user['role'];
                header("Location: admin.php");
                exit();
            } else {
                $error = "INVALID CREDENTIALS";
            }
        } else {
            $error = "USER NOT FOUND";
        }
    } else {
        $error = "DATABASE CONNECTION FAILED";
    }
}
?>

<!DOCTYPE html>
<html lang="en" data-theme="dark">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FITSTORE | Secure Authentication</title>
    <link
        href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;900&family=Rajdhani:wght@500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="themes.css">
    <style>
        body {
            background: var(--bg);
            color: var(--text);
            font-family: 'Outfit', sans-serif;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            margin: 0;
        }

        .login-container {
            width: 100%;
            max-width: 400px;
            background: var(--card);
            padding: 3rem;
            border-radius: 30px;
            border: 1px solid var(--card-border);
            text-align: center;
            backdrop-filter: blur(20px);
            position: relative;
            z-index: 10;
        }

        .logo {
            font-family: 'Rajdhani', sans-serif;
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 2rem;
        }

        .logo .fit {
            color: #fff;
        }

        .logo .store {
            color: var(--accent);
        }

        .form-group {
            margin-bottom: 1.5rem;
            text-align: left;
        }

        label {
            display: block;
            font-weight: 600;
            font-size: 0.8rem;
            color: var(--muted);
            margin-bottom: 0.5rem;
            text-transform: uppercase;
        }

        input {
            width: 100%;
            padding: 1rem;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--card-border);
            border-radius: 12px;
            color: #fff;
            font-family: inherit;
            outline: none;
            transition: 0.3s;
        }

        input:focus {
            border-color: var(--accent);
            background: rgba(255, 107, 0, 0.05);
        }

        .btn-login {
            width: 100%;
            padding: 1rem;
            background: var(--accent);
            color: #000;
            border: none;
            border-radius: 12px;
            font-weight: 800;
            font-size: 1rem;
            cursor: pointer;
            transition: 0.3s;
            margin-top: 1rem;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(255, 107, 0, 0.3);
        }

        .error-msg {
            background: rgba(239, 68, 68, 0.1);
            color: #ef4444;
            padding: 0.8rem;
            border-radius: 10px;
            font-size: 0.8rem;
            margin-bottom: 1.5rem;
            border: 1px solid rgba(239, 68, 68, 0.2);
            font-weight: 700;
        }

        .bg-glow {
            position: absolute;
            width: 400px;
            height: 400px;
            background: var(--accent);
            filter: blur(150px);
            opacity: 0.1;
            z-index: 1;
        }

        @media (max-width: 480px) {
            body {
                overflow: auto;
                align-items: flex-start;
                padding-top: 2rem;
            }

            .login-container {
                padding: 2rem 1.5rem;
                margin: 0 1rem;
                border-radius: 20px;
            }

            .logo {
                font-size: 2rem;
            }
        }
    </style>
</head>

<body>
    <div class="bg-glow"></div>
    <div class="login-container">
        <div class="logo">
            <span class="fit">FIT</span><span class="store">STORE</span>
        </div>

        <?php if ($error): ?>
            <div class="error-msg"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>Access Identity</label>
                <input type="text" name="username" placeholder="Username or Email" required>
            </div>

            <div class="form-group">
                <label>Security Key</label>
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit" class="btn-login">AUTHORIZE ACCESS</button>
        </form>

        <p style="margin-top: 2rem; font-size: 0.75rem; color: var(--muted); font-weight: 700;">
            SYSTEM SECURITY: LEVEL ALPHA ACTIVE
        </p>
    </div>
</body>

</html>